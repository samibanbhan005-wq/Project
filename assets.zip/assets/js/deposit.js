/* ==========================================================================
   Veltra — Deposit Instructions & Gateway
   ========================================================================== */

function initDeposit() {
  const user = Layout.requireAuth();
  if (!user) return;

  /* Wallet details */
  setText("gwNetwork", SETTINGS.walletNetwork);
  setText("gwTitle", SETTINGS.walletTitle);
  setText("gwNumber", SETTINGS.walletNumber);
  setText("gwIban", SETTINGS.walletIban);

  const walletText = `${SETTINGS.walletNetwork} — Title: ${SETTINGS.walletTitle}, Number: ${SETTINGS.walletNumber}, IBAN: ${SETTINGS.walletIban}`;
  document.querySelectorAll("[data-copy]").forEach((btn) => {
    btn.addEventListener("click", () => {
      const map = {
        title: SETTINGS.walletTitle,
        number: SETTINGS.walletNumber,
        iban: SETTINGS.walletIban
      };
      copyText(map[btn.dataset.copy], "Copied");
    });
  });
  const copyAll = document.getElementById("copyAllWallet");
  if (copyAll) copyAll.addEventListener("click", () => copyText(walletText, "Wallet details copied"));

  /* Prefill the member */
  const nameEl = document.getElementById("dName");
  const userEl = document.getElementById("dUsername");
  const emailEl = document.getElementById("dEmail");
  const senderEl = document.getElementById("dSender");
  if (nameEl) nameEl.value = `${user.firstName} ${user.lastName}`.trim();
  if (userEl) userEl.value = user.username;
  if (emailEl) emailEl.value = user.email;
  if (senderEl && user.phone) senderEl.value = user.phone;

  /* Plan selector */
  const planSelect = document.getElementById("dPlan");
  const amountEl = document.getElementById("dAmount");
  const params = new URLSearchParams(window.location.search);
  const wanted = params.get("plan");

  planSelect.innerHTML = PLANS.map((p) =>
    `<option value="${p.id}">${UIx.esc(p.name)} — ${UIx.money(p.amount)}</option>`).join("");
  if (wanted && Invest.planById(wanted)) planSelect.value = wanted;

  function syncAmount() {
    const plan = Invest.planById(planSelect.value);
    amountEl.value = plan ? UIx.money(plan.amount, false) : "";
    amountEl.dataset.value = plan ? plan.amount : "";
  }
  planSelect.addEventListener("change", syncAmount);
  syncAmount();

  /* Existing history */
  renderDepositHistory(user);

  /* Submit proof */
  const form = document.getElementById("depositForm");
  form.addEventListener("submit", (e) => {
    e.preventDefault();
    const sender = document.getElementById("dSender").value.trim();
    const tid = document.getElementById("dTid").value.trim();
    const confirmed = document.getElementById("dConfirm").checked;

    if (nameEl.value.trim().length < 3) return Toast.show("Enter your full name.", "error");
    if (!/^[^@\s]+@[^@\s]+\.[a-z]{2,}$/i.test(emailEl.value.trim())) return Toast.show("Enter a valid email address.", "error");
    if (!/^03\d{9}$/.test(sender.replace(/[\s-]/g, ""))) return Toast.show("Enter a valid 11-digit sender number.", "error");
    if (tid.length < 4) return Toast.show("Enter the Transaction ID (TID) from your receipt.", "error");
    if (!confirmed) return Toast.show("Please confirm the payment details checkbox.", "error");

    const res = Deposits.submit(user, {
      name: nameEl.value, username: userEl.value, email: emailEl.value,
      planId: planSelect.value, senderNumber: sender, tid
    });

    if (!res.ok) return Toast.show(res.error, "error");

    Toast.show("Deposit submitted — awaiting admin approval.", "success");
    form.reset();
    nameEl.value = `${user.firstName} ${user.lastName}`.trim();
    userEl.value = user.username;
    emailEl.value = user.email;
    if (user.phone) senderEl.value = user.phone;
    syncAmount();
    renderDepositHistory(Auth.current());
    Layout.render();
  });
}

function renderDepositHistory(user) {
  const wrap = document.getElementById("depHistory");
  if (!wrap) return;
  const list = DB.deposits.filter((d) => d.userId === user.id);
  if (!list.length) {
    wrap.innerHTML = `<div class="empty-state" style="padding:28px"><div class="icon">◎</div>
      <p class="mb-0 small">No deposits submitted yet.</p></div>`;
    return;
  }
  wrap.innerHTML = `<div class="grid" style="gap:10px">${list.slice(0, 5).map((d) => `
    <div class="mini-row">
      <div>
        <b class="small">${UIx.esc(d.planName)} · ${UIx.money(d.amount)}</b>
        <div class="tiny muted">TID ${UIx.esc(d.tid)} · ${UIx.dateTime(d.createdAt)}</div>
      </div>
      <span class="badge ${d.status === "pending" ? "badge-pending" : d.status === "approved" ? "badge-approved" : "badge-rejected"}">
        ${d.status.charAt(0).toUpperCase() + d.status.slice(1)}</span>
    </div>`).join("")}</div>`;
}

document.addEventListener("DOMContentLoaded", () => Veltra.onReady(initDeposit));
