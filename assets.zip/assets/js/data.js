/* ==========================================================================
   Veltra — Data Layer
   A self-contained "database" persisted in localStorage.
   Collections: users, deposits, withdrawals, transactions, feed, session.
   NOTE: This is a front-end demo build. Password hashing here is a demo
   digest only — a real deployment must hash on the server (bcrypt/argon2).
   ========================================================================== */

/* --------------------------------- Config -------------------------------- */
const PLANS = [
  {
    id: "beginner", name: "Beginner", amount: 1200, dailyRate: 0.030, duration: 30, tag: "",
    perks: ["Daily profit credited automatically", "30 days active cycle", "Standard support", "Referral income enabled"]
  },
  {
    id: "intermediate", name: "Intermediate", amount: 1600, dailyRate: 0.035, duration: 45, tag: "",
    perks: ["Higher daily profit rate", "45 days active cycle", "Priority support", "Referral income enabled"]
  },
  {
    id: "advanced", name: "Advanced", amount: 2600, dailyRate: 0.040, duration: 60, tag: "Most Popular",
    perks: ["Premium daily profit rate", "60 days active cycle", "Fast withdrawals", "Priority support", "Referral income enabled"]
  },
  {
    id: "vip", name: "VIP Master", amount: 4000, dailyRate: 0.050, duration: 90, tag: "Best Value",
    perks: ["Highest daily profit rate", "90 days active cycle", "VIP instant payouts", "Dedicated account manager", "Referral income enabled"]
  }
];

const SETTINGS = {
  walletTitle: "Tanzeel Ul Rahman",
  walletNumber: "03289693983",
  walletIban: "PK50 SADA 0000 0032 8969 3983",
  walletNetwork: "SadaPay",
  minWithdraw: 500,
  maxWithdraw: 500000,
  minDeposit: 1200,
  referralInstantRate: 0.10,   // 10% instant bonus on referral's first deposit
  referralDailyRate: 0.015,    // 1.5% daily commission from referral's daily profit
  profitCycleHours: 24,
  supportEmail: "support@veltra.pk",
  supportPhone: "+92 328 969 3983",
  supportWhatsapp: "+92 328 969 3983"
};

const WITHDRAW_METHODS = ["SadaPay", "EasyPaisa", "JazzCash"];

const KEYS = {
  users: "veltra_users",
  deposits: "veltra_deposits",
  withdrawals: "veltra_withdrawals",
  transactions: "veltra_transactions",
  feed: "veltra_feed",
  adminLog: "veltra_adminlog",
  session: "veltra_session"
};

/* --------------------------- Realtime collections ------------------------ */
/* Every collection is mirrored to Firebase under /veltra/<collection>.       */
const COLLECTIONS = ["users", "deposits", "withdrawals", "transactions", "feed", "adminLog"];

const KEY_TO_COL = {
  [KEYS.users]: "users",
  [KEYS.deposits]: "deposits",
  [KEYS.withdrawals]: "withdrawals",
  [KEYS.transactions]: "transactions",
  [KEYS.feed]: "feed",
  [KEYS.adminLog]: "adminLog"
};

/* ========================================================================
   Veltra runtime controller
   Readiness / change / connectivity hooks so pages can wait for the Firebase
   backend before they render and refresh when remote data arrives.
   ======================================================================== */
function safeCall(fn, arg) {
  try { fn(arg); } catch (e) { console.warn("[Veltra] handler failed", e); }
}

const Veltra = {
  isReady: false,
  online: true,
  _readyQ: [],
  _changeQ: [],
  _statusQ: [],

  /** Runs `fn` once the backend data is loaded (immediately if already ready). */
  onReady(fn) {
    if (this.isReady) safeCall(fn);
    else this._readyQ.push(fn);
  },
  /** Registers a listener fired whenever remote data changes. */
  onChange(fn) { this._changeQ.push(fn); },
  /** Registers a connectivity listener (invoked immediately with current state). */
  onStatus(fn) { this._statusQ.push(fn); safeCall(fn, this.online); },

  _flushReady() {
    this.isReady = true;
    const queue = this._readyQ;
    this._readyQ = [];
    queue.forEach((fn) => safeCall(fn));
  },
  _emitChange() { this._changeQ.forEach((fn) => safeCall(fn)); },
  _setOnline(value) {
    const next = !!value;
    if (this.online === next) return;
    this.online = next;
    this._statusQ.forEach((fn) => safeCall(fn, next));
  }
};

/* --------------------------- In-memory + cache store --------------------- */
/* STORE is the working set every page reads from. It is persisted to
   localStorage (offline cache) and synchronised to Firebase in the
   background. The public `DB` façade keeps the synchronous API used by
   the rest of the app. */
const STORE = {
  users: [], deposits: [], withdrawals: [], transactions: [], feed: [],
  dirty: {}, timers: {}, lastWrite: {}
};

function readLocal(key, fallback) {
  try {
    const raw = localStorage.getItem(key);
    return raw ? JSON.parse(raw) : fallback;
  } catch (e) { return fallback; }
}
function writeLocal(key, value) {
  try { localStorage.setItem(key, JSON.stringify(value)); } catch (e) { /* quota / private mode */ }
}

const DB = {
  read(key, fallback) {
    const col = KEY_TO_COL[key];
    return col ? STORE[col] : fallback;
  },
  write(key, value) {
    const col = KEY_TO_COL[key];
    if (!col) return;
    STORE[col] = value;
    writeLocal(key, value);
    scheduleFlush(col);
  },
  get users() { return STORE.users; },
  set users(v) { this.write(KEYS.users, v); },
  get deposits() { return STORE.deposits; },
  set deposits(v) { this.write(KEYS.deposits, v); },
  get withdrawals() { return STORE.withdrawals; },
  set withdrawals(v) { this.write(KEYS.withdrawals, v); },
  get transactions() { return STORE.transactions; },
  set transactions(v) { this.write(KEYS.transactions, v); },
  get feed() { return STORE.feed; },
  set feed(v) { this.write(KEYS.feed, v); },
  /* The session is per-device and must never be shared through the backend. */
  get session() { return readLocal(KEYS.session, null); },
  set session(v) {
    if (v) writeLocal(KEYS.session, v);
    else { try { localStorage.removeItem(KEYS.session); } catch (e) { /* ignore */ } }
  }
};

/* ========================================================================
   Remote synchronisation — Firebase Realtime Database
   ======================================================================== */
const SYNC = {
  basePath: "veltra",
  debounce: 450,      // ms to batch rapid local edits before pushing
  retryDelay: 4000,   // ms before retrying a failed push
  echoWindow: 1500    // ms to ignore our own writes echoed by the stream
};

/** Queues a debounced push of a single collection to Firebase. */
function scheduleFlush(col) {
  STORE.dirty[col] = true;
  clearTimeout(STORE.timers[col]);
  STORE.timers[col] = setTimeout(() => flushCollection(col), SYNC.debounce);
}

/** Pushes one collection to Firebase, retrying on failure. */
async function flushCollection(col) {
  if (!STORE.dirty[col]) return;
  STORE.dirty[col] = false;
  STORE.lastWrite[col] = Date.now();
  try {
    await FirebaseDB.put(SYNC.basePath + "/" + col, STORE[col]);
    Veltra._setOnline(true);
  } catch (e) {
    console.warn("[Veltra] sync failed for " + col + " — will retry", e.message);
    STORE.dirty[col] = true;
    Veltra._setOnline(false);
    clearTimeout(STORE.timers[col]);
    STORE.timers[col] = setTimeout(() => flushCollection(col), SYNC.retryDelay);
  }
}

/** Pushes every collection (used right after seeding the backend). */
async function flushAll() {
  const now = Date.now();
  const results = await Promise.all(COLLECTIONS.map(async (col) => {
    STORE.lastWrite[col] = now;
    STORE.dirty[col] = false;
    try {
      await FirebaseDB.put(SYNC.basePath + "/" + col, STORE[col]);
      return true;
    } catch (e) {
      STORE.dirty[col] = true;
      return false;
    }
  }));
  const failed = results.some((ok) => ok === false);
  Veltra._setOnline(!failed);
  return !failed;
}

/** Replaces the local store with a whole-tree snapshot from Firebase. */
function hydrateFromRemote(tree) {
  COLLECTIONS.forEach((col) => {
    if (Array.isArray(tree[col])) {
      STORE[col] = tree[col];
      writeLocal(KEYS[col], STORE[col]);
    }
  });
}

/** Returns true when a local write happened within the echo window. */
function recentlyWrote(col) {
  return Date.now() - (STORE.lastWrite[col] || 0) < SYNC.echoWindow;
}

/** Subscribes to live backend changes and keeps the store in step. */
function startRealtime() {
  if (!window.FirebaseDB || typeof FirebaseDB.watch !== "function") return;

  FirebaseDB.watch(SYNC.basePath, (msg) => {
    if (!msg || !msg.path) return;

    if (msg.path === "/") {
      const busy = COLLECTIONS.some(recentlyWrote);
      if (!msg.data || busy) return;
      hydrateFromRemote(msg.data);
    } else {
      const col = msg.path.split("/")[1];
      if (COLLECTIONS.indexOf(col) === -1) return;
      if (!Array.isArray(msg.data)) return;
      if (recentlyWrote(col)) return;
      if (JSON.stringify(msg.data) === JSON.stringify(STORE[col])) return;
      STORE[col] = msg.data;
      writeLocal(KEYS[col], STORE[col]);
    }

    Veltra._emitChange();
  });
}

const UIx = {
  money(n, withSymbol = true) {
    const num = Number(n || 0);
    const s = num.toLocaleString("en-PK", { minimumFractionDigits: 2, maximumFractionDigits: 2 });
    return withSymbol ? "Rs " + s : s;
  },
  compact(n) {
    const num = Number(n || 0);
    if (num >= 10000000) return (num / 10000000).toFixed(2) + " Cr";
    if (num >= 100000) return (num / 100000).toFixed(2) + " Lac";
    if (num >= 1000) return (num / 1000).toFixed(1) + "K";
    return String(Math.round(num));
  },
  date(iso) {
    if (!iso) return "—";
    const d = new Date(iso);
    return d.toLocaleDateString("en-GB", { day: "2-digit", month: "short", year: "numeric" });
  },
  dateTime(iso) {
    if (!iso) return "—";
    const d = new Date(iso);
    return d.toLocaleString("en-GB", { day: "2-digit", month: "short", hour: "2-digit", minute: "2-digit" });
  },
  timeAgo(iso) {
    const diff = (Date.now() - new Date(iso).getTime()) / 1000;
    if (diff < 60) return Math.max(1, Math.floor(diff)) + "s ago";
    if (diff < 3600) return Math.floor(diff / 60) + "m ago";
    if (diff < 86400) return Math.floor(diff / 3600) + "h ago";
    return Math.floor(diff / 86400) + "d ago";
  },
  maskUser(name) {
    if (!name) return "User";
    const n = String(name);
    return n.length <= 3 ? n.charAt(0) + "**" : n.slice(0, 3) + "***" + n.slice(-1);
  },
  esc(str) {
    return String(str == null ? "" : str)
      .replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;").replace(/'/g, "&#39;");
  },
  uid(prefix) {
    return prefix + "_" + Date.now().toString(36) + Math.random().toString(36).slice(2, 7);
  },
  daysBetween(a, b) {
    const d1 = new Date(a), d2 = new Date(b);
    const x = Date.UTC(d1.getFullYear(), d1.getMonth(), d1.getDate());
    const y = Date.UTC(d2.getFullYear(), d2.getMonth(), d2.getDate());
    return Math.floor((y - x) / 86400000);
  }
};

/* ------------------------------- Passwords ------------------------------- */
function hashPassword(pw) {
  const s = "veltra$" + String(pw);
  let h = 0x811c9dc5;
  for (let i = 0; i < s.length; i++) {
    h ^= s.charCodeAt(i);
    h = Math.imul(h, 0x01000193) >>> 0;
  }
  let b = "";
  try { b = btoa(unescape(encodeURIComponent(s))).slice(0, 20); } catch (e) { b = s.length.toString(36); }
  return "v1$" + h.toString(16).padStart(8, "0") + "$" + b;
}
function verifyPassword(pw, hash) {
  if (!hash) return false;
  return hashPassword(pw) === hash;
}

/* -------------------------- Referral code factory ------------------------ */
function makeReferralCode(username) {
  const base = String(username || "veltra").replace(/[^a-zA-Z]/g, "").toUpperCase().slice(0, 5) || "VELT";
  let code;
  do {
    code = base + Math.floor(1000 + Math.random() * 8999);
  } while (DB.users.some((u) => u.referralCode === code));
  return code;
}

/* ========================================================================
   Auth
   ======================================================================== */
const Auth = {
  current() {
    const s = DB.session;
    if (!s || !s.userId) return null;
    const u = DB.users.find((x) => x.id === s.userId);
    if (!u || u.status === "blocked") return null;
    return u;
  },
  isAdmin() {
    const u = this.current();
    return !!(u && u.role === "admin");
  },
  save(users) { DB.users = users; },
  findByLogin(identifier) {
    const k = String(identifier || "").trim().toLowerCase();
    return DB.users.find((u) => u.username.toLowerCase() === k || u.email.toLowerCase() === k);
  },
  register(payload) {
    const users = DB.users;
    const username = String(payload.username || "").trim();
    const email = String(payload.email || "").trim().toLowerCase();
    if (users.some((u) => u.username.toLowerCase() === username.toLowerCase())) {
      return { ok: false, error: "This username is already taken." };
    }
    if (users.some((u) => u.email.toLowerCase() === email)) {
      return { ok: false, error: "An account already exists with this email." };
    }
    const refCode = String(payload.referralCode || "").trim().toUpperCase();
    let referrer = null;
    if (refCode) {
      referrer = users.find((u) => u.referralCode === refCode);
      if (!referrer) return { ok: false, error: "Invalid referral code." };
    }
    const user = {
      id: UIx.uid("usr"),
      firstName: String(payload.firstName || "").trim(),
      lastName: String(payload.lastName || "").trim(),
      username,
      email,
      phone: String(payload.phone || "").trim(),
      password: hashPassword(payload.password),
      referralCode: makeReferralCode(username),
      referredBy: referrer ? referrer.username : null,
      balance: 0,
      totalDeposits: 0,
      totalWithdrawn: 0,
      totalProfit: 0,
      referralEarnings: 0,
      referralCount: 0,
      referralCommissionCount: 0,
      plan: null,
      status: "active",
      role: "user",
      createdAt: new Date().toISOString()
    };
    users.push(user);
    if (referrer) {
      const i = users.findIndex((u) => u.id === referrer.id);
      users[i].referralCount = (users[i].referralCount || 0) + 1;
    }
    Auth.save(users);
    DB.session = { userId: user.id };
    return { ok: true, user };
  },
  login(identifier, password) {
    const user = this.findByLogin(identifier);
    if (!user) return { ok: false, error: "No account found with those details." };
    if (!verifyPassword(password, user.password)) return { ok: false, error: "Incorrect password." };
    if (user.status === "blocked") return { ok: false, error: "Your account has been suspended. Contact support." };
    DB.session = { userId: user.id };
    return { ok: true, user };
  },
  logout() { DB.session = null; },
  refresh() { const u = this.current(); return u ? DB.users.find((x) => x.id === u.id) : null; }
};

/* ========================================================================
   Transactions & feed helpers
   ======================================================================== */
const Ledger = {
  add(userId, username, type, amount, note) {
    const tx = DB.transactions;
    const entry = {
      id: UIx.uid("tx"), userId, username: username || "system",
      type, amount: Number(amount || 0), note: note || "", createdAt: new Date().toISOString()
    };
    tx.unshift(entry);
    DB.transactions = tx.slice(0, 800);
    return entry;
  },
  forUser(userId, limit) {
    const list = DB.transactions.filter((t) => t.userId === userId);
    return limit ? list.slice(0, limit) : list;
  },
  pushFeed(name, type, amount) {
    const feed = DB.feed;
    feed.unshift({ id: UIx.uid("fd"), name, type, amount: Number(amount || 0), at: new Date().toISOString() });
    DB.feed = feed.slice(0, 120);
  }
};

/* ========================================================================
   Plans / profit engine
   ======================================================================== */
const Invest = {
  planById(id) { return PLANS.find((p) => p.id === id) || null; },
  dailyProfit(plan) { return plan.amount * plan.dailyRate; },
  totalReturn(plan) { return plan.amount + Invest.dailyProfit(plan) * plan.duration; },

  /**
   * Activates a plan for a user (called when a deposit is approved).
   */
  activatePlan(userId, planId) {
    const users = DB.users;
    const i = users.findIndex((u) => u.id === userId);
    if (i < 0) return null;
    const plan = Invest.planById(planId);
    if (!plan) return null;
    users[i].plan = {
      id: plan.id,
      name: plan.name,
      amount: plan.amount,
      dailyRate: plan.dailyRate,
      duration: plan.duration,
      startedAt: new Date().toISOString(),
      lastProfitAt: new Date().toISOString(),
      endedAt: null
    };
    users[i].totalDeposits = Number(users[i].totalDeposits || 0) + plan.amount;
    DB.users = users;
    return users[i];
  },

  /**
   * Credits accrued daily profit for every active plan and pays the
   * referrer 1.5% of the generated profit. Safe to call on every page load.
   */
  accrue() {
    const users = DB.users;
    let changed = false;
    users.forEach((u, idx) => {
      if (!u.plan || u.plan.endedAt || u.status === "blocked") return;
      const plan = u.plan;
      const elapsed = UIx.daysBetween(plan.startedAt, new Date());
      const paidDays = UIx.daysBetween(plan.startedAt, plan.lastProfitAt);
      const due = Math.min(elapsed - paidDays, plan.duration - paidDays);
      if (due <= 0) {
        if (elapsed >= plan.duration && !plan.endedAt) {
          users[idx].plan.endedAt = new Date().toISOString();
          changed = true;
        }
        return;
      }
      const profit = plan.amount * plan.dailyRate * due;
      users[idx].balance = Number(u.balance || 0) + profit;
      users[idx].totalProfit = Number(u.totalProfit || 0) + profit;
      const newLast = new Date(plan.lastProfitAt);
      newLast.setDate(newLast.getDate() + due);
      users[idx].plan.lastProfitAt = newLast.toISOString();
      if (paidDays + due >= plan.duration) users[idx].plan.endedAt = new Date().toISOString();

      Ledger.add(u.id, u.username, "profit", profit, `Daily profit • ${plan.name} (${due} day${due > 1 ? "s" : ""})`);
      Ledger.pushFeed(u.username, "profit", profit);

      // Referral recurring commission — 1.5% of the downline's daily profit
      if (u.referredBy) {
        const rIdx = users.findIndex((x) => x.username === u.referredBy);
        if (rIdx >= 0) {
          const commission = profit * SETTINGS.referralDailyRate;
          users[rIdx].balance = Number(users[rIdx].balance || 0) + commission;
          users[rIdx].referralEarnings = Number(users[rIdx].referralEarnings || 0) + commission;
          users[rIdx].referralCommissionCount = Number(users[rIdx].referralCommissionCount || 0) + 1;
          Ledger.add(users[rIdx].id, users[rIdx].username, "referral", commission,
            `${(SETTINGS.referralDailyRate * 100).toFixed(1)}% daily commission from @${u.username}`);
          Ledger.pushFeed(users[rIdx].username, "referral", commission);
        }
      }
      changed = true;
    });
    if (changed) DB.users = users;
  }
};

/* ========================================================================
   Deposits
   ======================================================================== */
const Deposits = {
  submit(user, data) {
    const plan = Invest.planById(data.planId);
    if (!plan) return { ok: false, error: "Please select a valid investment plan." };
    if (!data.senderNumber || String(data.senderNumber).replace(/\D/g, "").length < 10) {
      return { ok: false, error: "Enter the 11-digit number you sent the payment from." };
    }
    if (!data.tid || String(data.tid).trim().length < 4) {
      return { ok: false, error: "Enter a valid Transaction ID (TID) / reference number." };
    }
    const dup = DB.deposits.find(
      (d) => d.tid.toLowerCase() === String(data.tid).trim().toLowerCase() && d.status !== "rejected"
    );
    if (dup) return { ok: false, error: "This Transaction ID has already been submitted." };

    const rec = {
      id: UIx.uid("dep"),
      userId: user.id,
      name: (data.name || "").trim(),
      username: (data.username || user.username).trim(),
      email: (data.email || user.email).trim(),
      planId: plan.id,
      planName: plan.name,
      amount: plan.amount,
      senderNumber: String(data.senderNumber).trim(),
      tid: String(data.tid).trim(),
      method: SETTINGS.walletNetwork,
      status: "pending",
      note: "",
      createdAt: new Date().toISOString(),
      reviewedAt: null
    };
    const list = DB.deposits;
    list.unshift(rec);
    DB.deposits = list;
    Ledger.add(user.id, user.username, "deposit", plan.amount, `Deposit submitted • ${plan.name} (pending approval)`);
    Ledger.pushFeed(user.username, "deposit", plan.amount);
    return { ok: true, deposit: rec };
  },

  approve(depositId, adminName) {
    const list = DB.deposits;
    const i = list.findIndex((d) => d.id === depositId);
    if (i < 0) return { ok: false, error: "Deposit not found." };
    if (list[i].status !== "pending") return { ok: false, error: "This deposit is already processed." };
    const dep = list[i];
    const users = DB.users;
    const uIdx = users.findIndex((u) => u.id === dep.userId);
    if (uIdx < 0) return { ok: false, error: "User not found." };

    const isFirstDeposit = !users[uIdx].totalDeposits || users[uIdx].totalDeposits === 0;

    list[i].status = "approved";
    list[i].reviewedAt = new Date().toISOString();
    list[i].reviewedBy = adminName || "admin";
    DB.deposits = list;

    Invest.activatePlan(dep.userId, dep.planId);

    Ledger.add(dep.userId, dep.username, "deposit", dep.amount,
      `Deposit approved • ${dep.planName} activated (TID ${dep.tid})`);

    // 10% instant referral bonus on the referral's FIRST deposit
    let bonusPaid = 0;
    const fresh = DB.users.find((u) => u.id === dep.userId);
    if (isFirstDeposit && fresh && fresh.referredBy) {
      const usersNow = DB.users;
      const rIdx = usersNow.findIndex((x) => x.username === fresh.referredBy);
      if (rIdx >= 0) {
        bonusPaid = dep.amount * SETTINGS.referralInstantRate;
        usersNow[rIdx].balance = Number(usersNow[rIdx].balance || 0) + bonusPaid;
        usersNow[rIdx].referralEarnings = Number(usersNow[rIdx].referralEarnings || 0) + bonusPaid;
        Ledger.add(usersNow[rIdx].id, usersNow[rIdx].username, "referral", bonusPaid,
          `${(SETTINGS.referralInstantRate * 100).toFixed(0)}% instant bonus — first deposit of @${fresh.username}`);
        Ledger.pushFeed(usersNow[rIdx].username, "referral", bonusPaid);
        DB.users = usersNow;
      }
    }
    return { ok: true, bonusPaid };
  },

  reject(depositId, note, adminName) {
    const list = DB.deposits;
    const i = list.findIndex((d) => d.id === depositId);
    if (i < 0) return { ok: false, error: "Deposit not found." };
    if (list[i].status !== "pending") return { ok: false, error: "This deposit is already processed." };
    list[i].status = "rejected";
    list[i].note = note || "Payment could not be verified.";
    list[i].reviewedAt = new Date().toISOString();
    list[i].reviewedBy = adminName || "admin";
    DB.deposits = list;
    Ledger.add(list[i].userId, list[i].username, "deposit", 0,
      `Deposit rejected (TID ${list[i].tid}) — ${list[i].note}`);
    return { ok: true };
  }
};

/* ========================================================================
   Withdrawals
   ======================================================================== */
const Withdrawals = {
  submit(user, data) {
    const amount = Number(data.amount);
    if (!amount || amount <= 0) return { ok: false, error: "Enter a valid withdrawal amount." };
    if (amount < SETTINGS.minWithdraw) return { ok: false, error: `Minimum withdrawal is ${UIx.money(SETTINGS.minWithdraw)}.` };
    if (amount > SETTINGS.maxWithdraw) return { ok: false, error: `Maximum withdrawal per request is ${UIx.money(SETTINGS.maxWithdraw)}.` };
    if (!WITHDRAW_METHODS.includes(data.method)) return { ok: false, error: "Choose a valid payout method." };
    if (!data.title || String(data.title).trim().length < 3) return { ok: false, error: "Enter the account holder title." };
    if (!data.accountNumber || String(data.accountNumber).replace(/\D/g, "").length < 10) {
      return { ok: false, error: "Enter a valid account / mobile number." };
    }

    const users = DB.users;
    const i = users.findIndex((u) => u.id === user.id);
    if (i < 0) return { ok: false, error: "User not found." };
    if (Number(users[i].balance) < amount) {
      return { ok: false, error: `Insufficient balance. Available: ${UIx.money(users[i].balance)}.` };
    }

    // Balance is held as soon as the request is submitted (refunded on rejection)
    users[i].balance = Number(users[i].balance) - amount;
    DB.users = users;

    const rec = {
      id: UIx.uid("wdr"),
      userId: user.id,
      username: user.username,
      amount,
      method: data.method,
      title: String(data.title).trim(),
      accountNumber: String(data.accountNumber).trim(),
      status: "pending",
      note: "",
      createdAt: new Date().toISOString(),
      reviewedAt: null
    };
    const list = DB.withdrawals;
    list.unshift(rec);
    DB.withdrawals = list;
    Ledger.add(user.id, user.username, "withdraw", -amount,
      `Withdrawal requested • ${data.method} (${rec.accountNumber}) — on hold`);
    return { ok: true, withdrawal: rec };
  },

  dispatch(id, adminName) {
    const list = DB.withdrawals;
    const i = list.findIndex((w) => w.id === id);
    if (i < 0) return { ok: false, error: "Request not found." };
    if (list[i].status !== "pending") return { ok: false, error: "This request is already processed." };
    list[i].status = "approved";
    list[i].reviewedAt = new Date().toISOString();
    list[i].reviewedBy = adminName || "admin";
    DB.withdrawals = list;

    const users = DB.users;
    const uIdx = users.findIndex((u) => u.id === list[i].userId);
    if (uIdx >= 0) {
      users[uIdx].totalWithdrawn = Number(users[uIdx].totalWithdrawn || 0) + list[i].amount;
      DB.users = users;
      Ledger.add(list[i].userId, list[i].username, "withdraw", 0,
        `Withdrawal dispatched • ${UIx.money(list[i].amount)} via ${list[i].method}`);
      Ledger.pushFeed(list[i].username, "withdraw", list[i].amount);
    }
    return { ok: true };
  },

  reject(id, note, adminName) {
    const list = DB.withdrawals;
    const i = list.findIndex((w) => w.id === id);
    if (i < 0) return { ok: false, error: "Request not found." };
    if (list[i].status !== "pending") return { ok: false, error: "This request is already processed." };
    list[i].status = "rejected";
    list[i].note = note || "Request rejected by administration.";
    list[i].reviewedAt = new Date().toISOString();
    list[i].reviewedBy = adminName || "admin";
    DB.withdrawals = list;

    // Auto-refund the held amount
    const users = DB.users;
    const uIdx = users.findIndex((u) => u.id === list[i].userId);
    if (uIdx >= 0) {
      users[uIdx].balance = Number(users[uIdx].balance || 0) + list[i].amount;
      DB.users = users;
      Ledger.add(list[i].userId, list[i].username, "refund", list[i].amount,
        `Withdrawal rejected — ${UIx.money(list[i].amount)} auto-refunded to balance`);
    }
    return { ok: true };
  }
};

/* ========================================================================
   Admin utilities
   ======================================================================== */
const Admin = {
  adjustBalance(userId, newBalance, note, adminName) {
    const users = DB.users;
    const i = users.findIndex((u) => u.id === userId);
    if (i < 0) return { ok: false, error: "User not found." };
    const prev = Number(users[i].balance || 0);
    const next = Number(newBalance);
    if (isNaN(next) || next < 0) return { ok: false, error: "Enter a valid balance." };
    users[i].balance = next;
    DB.users = users;
    Ledger.add(userId, users[i].username, "admin", next - prev,
      `${note || "Balance adjusted by admin"} (${UIx.money(prev)} → ${UIx.money(next)})`);
    return { ok: true };
  },
  toggleBlock(userId, adminName) {
    const users = DB.users;
    const i = users.findIndex((u) => u.id === userId);
    if (i < 0) return { ok: false, error: "User not found." };
    users[i].status = users[i].status === "blocked" ? "active" : "blocked";
    users[i].statusChangedAt = new Date().toISOString();
    DB.users = users;
    Ledger.add(userId, users[i].username, "admin", 0,
      `Account ${users[i].status === "blocked" ? "blocked" : "activated"} by ${adminName || "admin"}`);
    return { ok: true, status: users[i].status };
  },
  stats() {
    const users = DB.users.filter((u) => u.role !== "admin");
    const deps = DB.deposits;
    const wds = DB.withdrawals;
    const approvedDeps = deps.filter((d) => d.status === "approved");
    return {
      totalUsers: users.length,
      activeUsers: users.filter((u) => u.status === "active").length,
      blockedUsers: users.filter((u) => u.status === "blocked").length,
      investingUsers: users.filter((u) => u.plan && !u.plan.endedAt).length,
      pendingDeposits: deps.filter((d) => d.status === "pending").length,
      pendingWithdrawals: wds.filter((w) => w.status === "pending").length,
      totalDeposits: approvedDeps.reduce((s, d) => s + d.amount, 0),
      depositCount: approvedDeps.length,
      totalPayouts: wds.filter((w) => w.status === "approved").reduce((s, w) => s + w.amount, 0),
      totalBalances: users.reduce((s, u) => s + Number(u.balance || 0), 0),
      referralPayouts: users.reduce((s, u) => s + Number(u.referralEarnings || 0), 0),
      totalProfitPaid: users.reduce((s, u) => s + Number(u.totalProfit || 0), 0)
    };
  }
};

/* ========================================================================
   Seed — demo users, deposits, withdrawals and live feed
   ======================================================================== */
function daysAgoIso(days, hours) {
  const d = new Date();
  d.setDate(d.getDate() - (days || 0));
  if (hours) d.setHours(d.getHours() - hours);
  return d.toISOString();
}

function seedDatabase() {
  const mkUser = (o) => Object.assign({
    firstName: "", lastName: "", username: "", email: "", phone: "",
    password: hashPassword("veltra123"),
    referralCode: "", referredBy: null,
    balance: 0, totalDeposits: 0, totalWithdrawn: 0, totalProfit: 0,
    referralEarnings: 0, referralCount: 0, referralCommissionCount: 0,
    plan: null, status: "active", role: "user", createdAt: new Date().toISOString()
  }, o);

  const users = [];

  users.push(mkUser({
    id: "usr_admin", firstName: "Veltra", lastName: "Admin", username: "admin",
    email: "admin@veltra.pk", phone: "03289693983",
    password: hashPassword("admin123"), referralCode: "ADMIN000",
    role: "admin", createdAt: daysAgoIso(180)
  }));

  users.push(mkUser({
    id: "usr_demo", firstName: "Demo", lastName: "Investor", username: "demo",
    email: "demo@veltra.pk", phone: "03001234567",
    password: hashPassword("demo123"), referralCode: "DEMO2048",
    referralCount: 2, balance: 18750.45, totalDeposits: 2600, totalProfit: 6240,
    referralEarnings: 1290.6, totalWithdrawn: 3200, createdAt: daysAgoIso(64),
    plan: {
      id: "advanced", name: "Advanced", amount: 2600, dailyRate: 0.04, duration: 60,
      startedAt: daysAgoIso(26), lastProfitAt: daysAgoIso(0), endedAt: null
    }
  }));

  users.push(mkUser({
    id: "usr_ayesha", firstName: "Ayesha", lastName: "Khan", username: "ayesha",
    email: "ayesha@example.com", phone: "03019876543", referralCode: "AYESH7712",
    referredBy: "demo", balance: 8420.2, totalDeposits: 1600, totalProfit: 2240,
    referralEarnings: 96.5, createdAt: daysAgoIso(41),
    plan: {
      id: "intermediate", name: "Intermediate", amount: 1600, dailyRate: 0.035, duration: 45,
      startedAt: daysAgoIso(32), lastProfitAt: daysAgoIso(0), endedAt: null
    }
  }));

  users.push(mkUser({
    id: "usr_bilal", firstName: "Bilal", lastName: "Ahmed", username: "bilal",
    email: "bilal@example.com", phone: "03211122334", referralCode: "BILAL3390",
    referredBy: "demo", balance: 3910, totalDeposits: 1200, totalProfit: 1080,
    referralEarnings: 24.3, createdAt: daysAgoIso(22),
    plan: {
      id: "beginner", name: "Beginner", amount: 1200, dailyRate: 0.03, duration: 30,
      startedAt: daysAgoIso(20), lastProfitAt: daysAgoIso(0), endedAt: null
    }
  }));

  users.push(mkUser({
    id: "usr_usman", firstName: "Usman", lastName: "Malik", username: "usman",
    email: "usman@example.com", phone: "03451239876", referralCode: "USMAN4501",
    balance: 0, totalDeposits: 0, createdAt: daysAgoIso(3)
  }));

  users.push(mkUser({
    id: "usr_hamza", firstName: "Hamza", lastName: "Sheikh", username: "hamza",
    email: "hamza@example.com", phone: "03334455667", referralCode: "HAMZA5514",
    status: "blocked", balance: 0, totalDeposits: 0, createdAt: daysAgoIso(9)
  }));

  users.push(mkUser({
    id: "usr_sana", firstName: "Sana", lastName: "Tariq", username: "sana",
    email: "sana@example.com", phone: "03457788990", referralCode: "SANA8823",
    balance: 2600, totalDeposits: 4000, totalProfit: 4800, totalWithdrawn: 5000, createdAt: daysAgoIso(52),
    plan: {
      id: "vip", name: "VIP Master", amount: 4000, dailyRate: 0.05, duration: 90,
      startedAt: daysAgoIso(48), lastProfitAt: daysAgoIso(0), endedAt: null
    }
  }));

  const mkDep = (id, user, planId, offsetDays, status, tid) => {
    const plan = PLANS.find((p) => p.id === planId);
    return {
      id, userId: user.id, name: user.firstName + " " + user.lastName, username: user.username,
      email: user.email, planId, planName: plan.name, amount: plan.amount,
      senderNumber: user.phone, tid, method: SETTINGS.walletNetwork, status,
      note: status === "rejected" ? "Sender number does not match the TID." : "",
      createdAt: daysAgoIso(offsetDays), reviewedAt: status === "pending" ? null : daysAgoIso(offsetDays - 1),
      reviewedBy: status === "pending" ? null : "admin"
    };
  };

  const deposits = [
    mkDep("dep_seed1", users[4], "beginner", 1, "pending", "SP-8842137"),
    mkDep("dep_seed2", users[1], "advanced", 26, "approved", "SP-7712903"),
    mkDep("dep_seed3", users[2], "intermediate", 32, "approved", "SP-6612094"),
    mkDep("dep_seed4", users[3], "beginner", 20, "approved", "SP-5590211"),
    mkDep("dep_seed5", users[6], "vip", 48, "approved", "SP-4408876"),
    mkDep("dep_seed6", users[4], "beginner", 6, "rejected", "SP-3391120")
  ];

  const withdrawals = [
    { id: "wdr_seed1", userId: users[1].id, username: users[1].username, amount: 3200, method: "SadaPay",
      title: "Demo Investor", accountNumber: "03001234567", status: "approved",
      note: "", createdAt: daysAgoIso(12), reviewedAt: daysAgoIso(12), reviewedBy: "admin" },
    { id: "wdr_seed2", userId: users[2].id, username: users[2].username, amount: 1500, method: "EasyPaisa",
      title: "Ayesha Khan", accountNumber: "03019876543", status: "pending",
      note: "", createdAt: daysAgoIso(1), reviewedAt: null },
    { id: "wdr_seed3", userId: users[3].id, username: users[3].username, amount: 700, method: "JazzCash",
      title: "Bilal Ahmed", accountNumber: "03211122334", status: "rejected",
      note: "Account title mismatch.", createdAt: daysAgoIso(4), reviewedAt: daysAgoIso(3), reviewedBy: "admin" },
    { id: "wdr_seed4", userId: users[6].id, username: users[6].username, amount: 5000, method: "SadaPay",
      title: "Sana Tariq", accountNumber: "03457788990", status: "approved",
      note: "", createdAt: daysAgoIso(9), reviewedAt: daysAgoIso(9), reviewedBy: "admin" }
  ];

  const transactions = [];
  const txSeed = [
    [users[1], "deposit", 2600, "Deposit approved • Advanced activated (TID SP-7712903)", 26],
    [users[1], "profit", 8320, "Daily profit • Advanced (80 days)", 25],
    [users[1], "referral", 240, "10% instant bonus — first deposit of @ayesha", 32],
    [users[1], "withdraw", -3200, "Withdrawal dispatched • Rs 3,200.00 via SadaPay", 12],
    [users[2], "profit", 2240, "Daily profit • Intermediate (40 days)", 31],
    [users[3], "profit", 1080, "Daily profit • Beginner (30 days)", 19]
  ];
  txSeed.forEach((t, i) => transactions.push({
    id: "tx_seed" + i, userId: t[0].id, username: t[0].username, type: t[1],
    amount: t[2], note: t[3], createdAt: daysAgoIso(t[4])
  }));
  transactions.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));

  const names = ["Faisal", "Zainab", "Usman", "Maryam", "Talha", "Iqra", "Rehan", "Noor",
    "Saad", "Hina", "Danish", "Amna", "Kashif", "Rabia", "Junaid", "Mehwish",
    "Arsalan", "Farah", "Shahid", "Nimra", "Owais", "Areeba", "Tahir", "Sadia"];
  const feed = [];
  for (let i = 0; i < 40; i++) {
    const t = ["deposit", "profit", "withdraw", "referral"][Math.floor(Math.random() * 4)];
    const base = t === "deposit" ? 1200 + Math.random() * 3000 : 40 + Math.random() * 4800;
    feed.push({
      id: "fd_seed" + i,
      name: names[Math.floor(Math.random() * names.length)] + Math.floor(10 + Math.random() * 89),
      type: t,
      amount: Math.round(base * 100) / 100,
      at: new Date(Date.now() - i * 1000 * (60 + Math.random() * 900)).toISOString()
    });
  }

  STORE.users = users;
  STORE.deposits = deposits;
  STORE.withdrawals = withdrawals;
  STORE.transactions = transactions;
  STORE.feed = feed;
  COLLECTIONS.forEach((col) => writeLocal(KEYS[col], STORE[col]));
}

/* --------------------------------- Boot ---------------------------------- */
/**
 * Connects to the Firebase backend, seeds it the first time it is empty and
 * falls back to the local cache when the network is unavailable. Resolves
 * the Veltra ready queue once data is available.
 */
async function bootDatabase() {
  COLLECTIONS.forEach((col) => { STORE[col] = readLocal(KEYS[col], []) || []; });

  try {
    const tree = await FirebaseDB.get(SYNC.basePath);
    if (!tree || !Array.isArray(tree.users) || tree.users.length === 0) {
      console.info("[Veltra] backend is empty — seeding Firebase database…");
      seedDatabase();
      await flushAll();
    } else {
      hydrateFromRemote(tree);
      Veltra._setOnline(true);
    }
  } catch (e) {
    console.warn("[Veltra] backend unreachable — running on local cache:", e.message);
    Veltra._setOnline(false);
    if (!STORE.users.length) seedDatabase();
  }

  try { Invest.accrue(); } catch (e) { console.warn("[Veltra] profit accrual skipped", e); }

  startRealtime();
  Veltra._flushReady();
}

bootDatabase();
