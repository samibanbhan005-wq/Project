/* ==========================================================================
   Veltra — Plans & Pricing Page
   ========================================================================== */

function initPlans() {
  const grid = document.getElementById("plansGrid");
  if (grid) {
    grid.innerHTML = PLANS.map((p) => {
      const user = Auth.current();
      const href = user ? `deposit.html?plan=${p.id}` : `register.html?plan=${p.id}`;
      const cta = user ? `Invest ${UIx.money(p.amount, false)}` : "Register to Invest";
      return PlanCard.render(p, { featured: p.id === "advanced", cta, href });
    }).join("");
  }

  const body = document.getElementById("compareBody");
  if (body) {
    body.innerHTML = PLANS.map((p) => {
      const daily = p.amount * p.dailyRate;
      const total = p.amount + daily * p.duration;
      const user = Auth.current();
      const href = user ? `deposit.html?plan=${p.id}` : `register.html?plan=${p.id}`;
      return `
        <tr>
          <td><b>${UIx.esc(p.name)}</b>${p.tag ? ` <span class="badge badge-active">${UIx.esc(p.tag)}</span>` : ""}</td>
          <td class="mono">${UIx.money(p.amount)}</td>
          <td class="mono up">${UIx.money(daily)}</td>
          <td class="accent"><b>${(p.dailyRate * 100).toFixed(1)}%</b></td>
          <td>${p.duration} days</td>
          <td class="mono">${UIx.money(total)}</td>
          <td class="mono up">${UIx.money(total - p.amount)}</td>
          <td><a class="btn btn-outline btn-sm" href="${href}">Invest Now</a></td>
        </tr>`;
    }).join("");
  }
}

document.addEventListener("DOMContentLoaded", () => Veltra.onReady(initPlans));
