/* ==========================================================================
   Veltra — Authentication Pages (Login & Register)
   ========================================================================== */

function queryParam(name) {
  return new URLSearchParams(window.location.search).get(name);
}

function afterAuth(user) {
  const next = queryParam("next");
  Toast.show(`Welcome, ${user.firstName || user.username}!`, "success");
  const target = user.role === "admin" ? "admin.html" : (next || "dashboard.html");
  setTimeout(() => (window.location.href = target), 700);
}

function showError(id, message) {
  const box = document.getElementById(id);
  if (!box) return;
  box.querySelector("div").textContent = message;
  box.classList.remove("hidden");
}

function hideError(id) {
  const box = document.getElementById(id);
  if (box) box.classList.add("hidden");
}

/* ------------------------------- Score meter ----------------------------- */
function passwordScore(pw) {
  let score = 0;
  if (pw.length >= 6) score++;
  if (pw.length >= 10) score++;
  if (/[A-Z]/.test(pw) && /[a-z]/.test(pw)) score++;
  if (/\d/.test(pw)) score++;
  if (/[^A-Za-z0-9]/.test(pw)) score++;
  return Math.min(score, 4);
}

function initStrength() {
  const pw = document.getElementById("password");
  const bar = document.getElementById("strengthBar");
  const text = document.getElementById("strengthText");
  if (!pw || !bar || !text) return;
  const labels = ["Very weak", "Weak", "Fair", "Strong", "Very strong"];
  const colors = ["#f43f5e", "#f43f5e", "#f59e0b", "#33c98e", "#00e6c3"];
  pw.addEventListener("input", () => {
    const score = passwordScore(pw.value);
    const pct = pw.value ? (score / 4) * 100 : 0;
    bar.style.width = pct + "%";
    bar.style.background = colors[score];
    text.textContent = "Password strength: " + (pw.value ? labels[score] : "—");
  });
}

/* --------------------------------- Login -------------------------------- */
function initLogin() {
  const form = document.getElementById("loginForm");
  if (!form) return;

  if (Auth.current()) {
    window.location.href = Auth.isAdmin() ? "admin.html" : "dashboard.html";
    return;
  }

  form.addEventListener("submit", (e) => {
    e.preventDefault();
    hideError("loginError");
    const id = document.getElementById("loginId").value.trim();
    const pw = document.getElementById("loginPassword").value;

    if (!id) return showError("loginError", "Please enter your username or email address.");
    if (!pw) return showError("loginError", "Please enter your password.");

    const res = Auth.login(id, pw);
    if (!res.ok) {
      showError("loginError", res.error);
      Toast.show(res.error, "error");
      return;
    }
    afterAuth(res.user);
  });
}

/* ------------------------------- Register ------------------------------- */
function initRegister() {
  const form = document.getElementById("registerForm");
  if (!form) return;

  if (Auth.current()) {
    window.location.href = "dashboard.html";
    return;
  }

  const refInput = document.getElementById("referralCode");
  const refFromUrl = queryParam("ref");
  if (refFromUrl && refInput) refInput.value = refFromUrl.toUpperCase();

  const planFromUrl = queryParam("plan");
  if (planFromUrl) Toast.show("Complete your account to invest in the " + planFromUrl + " plan.", "");

  form.addEventListener("submit", (e) => {
    e.preventDefault();
    hideError("registerError");

    const payload = {
      firstName: document.getElementById("firstName").value.trim(),
      lastName: document.getElementById("lastName").value.trim(),
      username: document.getElementById("username").value.trim(),
      phone: document.getElementById("phone").value.trim(),
      email: document.getElementById("email").value.trim(),
      password: document.getElementById("password").value,
      confirm: document.getElementById("confirmPassword").value,
      referralCode: document.getElementById("referralCode").value.trim()
    };
    const terms = document.getElementById("terms").checked;

    if (payload.firstName.length < 2) return showError("registerError", "Please enter your first name.");
    if (payload.lastName.length < 2) return showError("registerError", "Please enter your last name.");
    if (!/^[A-Za-z0-9_]{4,20}$/.test(payload.username)) {
      return showError("registerError", "Username must be 4–20 characters (letters, numbers, underscore).");
    }
    if (!/^03\d{9}$/.test(payload.phone.replace(/[\s-]/g, ""))) {
      return showError("registerError", "Enter a valid Pakistani mobile number (e.g. 03001234567).");
    }
    if (!/^[^@\s]+@[^@\s]+\.[a-z]{2,}$/i.test(payload.email)) {
      return showError("registerError", "Please enter a valid email address.");
    }
    if (payload.password.length < 6) {
      return showError("registerError", "Password must be at least 6 characters long.");
    }
    if (payload.password !== payload.confirm) {
      return showError("registerError", "Passwords do not match.");
    }
    if (!terms) return showError("registerError", "Please accept the Terms of Service to continue.");

    const res = Auth.register(payload);
    if (!res.ok) {
      showError("registerError", res.error);
      Toast.show(res.error, "error");
      return;
    }
    Ledger.add(res.user.id, res.user.username, "account", 0,
      "Account created" + (res.user.referredBy ? ` • referred by @${res.user.referredBy}` : ""));
    afterAuth(res.user);
  });
}

document.addEventListener("DOMContentLoaded", () => {
  Veltra.onReady(() => {
    initStrength();
    initLogin();
    initRegister();
  });
});
