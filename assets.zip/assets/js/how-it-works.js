/* ==========================================================================
   Veltra — How It Works (profit calculator)
   ========================================================================== */

function initCalculator() {
  const select = document.getElementById("calcPlan");
  const daysInput = document.getElementById("calcDays");
  if (!select || !daysInput) return;

  select.innerHTML = PLANS.map((p) =>
    `<option value="${p.id}">${UIx.esc(p.name)} — ${UIx.money(p.amount)}</option>`).join("");
  select.value = "advanced";

  function recalc() {
    const plan = Invest.planById(select.value);
    if (!plan) return;
    const requested = Math.max(1, Math.min(365, Number(daysInput.value) || 1));
    const effective = Math.min(requested, plan.duration);
    const daily = plan.amount * plan.dailyRate;
    const profit = daily * effective;

    setText("calcAmount", UIx.money(plan.amount));
    setText("calcDaily", UIx.money(daily) + "  (" + (plan.dailyRate * 100).toFixed(1) + "%)");
    setText("calcProfit", UIx.money(profit));
    setText("calcTotal", UIx.money(plan.amount + profit));
    setText("calcRef", UIx.money(profit * SETTINGS.referralDailyRate));
  }

  select.addEventListener("change", recalc);
  daysInput.addEventListener("input", recalc);
  recalc();
}

document.addEventListener("DOMContentLoaded", () => Veltra.onReady(initCalculator));
