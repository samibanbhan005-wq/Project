/* ==========================================================================
   Veltra — Contact & Support Page
   ========================================================================== */

function initContact() {
  /* Prefill for signed-in members */
  const user = Auth.current();
  if (user) {
    const name = document.getElementById("cName");
    const email = document.getElementById("cEmail");
    const uname = document.getElementById("cUsername");
    if (name) name.value = `${user.firstName} ${user.lastName}`.trim();
    if (email) email.value = user.email;
    if (uname) uname.value = user.username;
  }

  /* Wallet details */
  setText("ccTitle", SETTINGS.walletTitle);
  setText("ccNumber", SETTINGS.walletNumber);
  setText("ccIban", SETTINGS.walletIban);

  const copyWalletBtn = document.getElementById("copyWallet");
  if (copyWalletBtn) {
    copyWalletBtn.addEventListener("click", () => copyText(
      `${SETTINGS.walletNetwork} — Title: ${SETTINGS.walletTitle}, Number: ${SETTINGS.walletNumber}, IBAN: ${SETTINGS.walletIban}`,
      "Wallet details copied"
    ));
  }

  /* Ticket form */
  const form = document.getElementById("contactForm");
  if (!form) return;

  form.addEventListener("submit", (e) => {
    e.preventDefault();
    const name = document.getElementById("cName").value.trim();
    const email = document.getElementById("cEmail").value.trim();
    const topic = document.getElementById("cTopic").value;
    const username = document.getElementById("cUsername").value.trim();
    const message = document.getElementById("cMessage").value.trim();

    if (name.length < 3) return Toast.show("Please enter your full name.", "error");
    if (!/^[^@\s]+@[^@\s]+\.[a-z]{2,}$/i.test(email)) return Toast.show("Please enter a valid email address.", "error");
    if (message.length < 10) return Toast.show("Please describe your issue in a little more detail.", "error");

    const tickets = JSON.parse(localStorage.getItem("veltra_tickets") || "[]");
    tickets.unshift({
      id: UIx.uid("tkt"), name, email, topic, username, message,
      user: user ? user.username : null, status: "open", createdAt: new Date().toISOString()
    });
    localStorage.setItem("veltra_tickets", JSON.stringify(tickets.slice(0, 200)));

    document.getElementById("contactSuccess").classList.remove("hidden");
    Toast.show("Message sent — support will reply within 24 hours.", "success");
    form.reset();
    if (user) {
      document.getElementById("cName").value = `${user.firstName} ${user.lastName}`.trim();
      document.getElementById("cEmail").value = user.email;
      document.getElementById("cUsername").value = user.username;
    }
  });
}

document.addEventListener("DOMContentLoaded", () => Veltra.onReady(initContact));
