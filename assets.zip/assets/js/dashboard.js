/* ==========================================================================
   Veltra — User Dashboard
   ========================================================================== */

function statusBadge(status) {
  const map = { pending: "badge-pending", approved: "badge-approved", rejected: "badge-rejected" };
  const label = { pending: "Pending", approved: "Approved", rejected: "Rejected" };
  return `<span class="badge ${map[status] || "badge-neutral"}">${label[status] || status}</span>`;
}

function txBadge(type) {
  const map = {
    profit: ["badge-approved", "Daily Profit"],
    referral: ["badge-active", "Referral"],
    deposit: ["badge-pending", "Deposit"],
    withdraw: ["badge-rejected", "Withdrawal"],
    refund: ["badge-neutral", "Refund"],
    admin: ["badge-neutral", "Admin"],
    account: ["badge-neutral", "Account"]
  };
  const m = map[type] || ["badge-neutral", type];
  return `<span class="badge ${m[0]}">${m[1]}</span>`;
}

function emptyRow(cols, text) {
  return `<tr><td colspan="${cols}"><div class="empty-state"><div class="icon">◎</div>
    <p class="mb-0">${UIx.esc(text)}</p></div></td></tr>`;
}

function renderKPIs(user) {
  const grid = document.getElementById("kpiGrid");
  if (!grid) return;
  const items = [
    ["Available Balance", UIx.money(user.balance), "Ready to withdraw", "🏦"],
    ["Total Profit Earned", UIx.money(user.totalProfit), "From daily plan credits", "📈"],
    ["Referral Earnings", UIx.money(user.referralEarnings), (user.referralCount || 0) + " referral(s)", "👥"],
    ["Total Withdrawn", UIx.money(user.totalWithdrawn), "Successfully dispatched", "↗"]
  ];
  grid.innerHTML = items.map(([label, value, sub, icon]) => `
    <div class="kpi">
      <div class="kpi-top"><span class="kpi-label">${label}</span>
        <span class="icon-box" style="width:36px;height:36px;flex:0 0 36px">${icon}</span></div>
      <div class="kpi-value">${value}</div>
      <div class="tiny muted">${sub}</div>
    </div>`).join("");
}

function renderPlan(user) {
  const wrap = document.getElementById("planCard");
  if (!wrap) return;

  if (!user.plan) {
    wrap.innerHTML = `
      <h3>No active plan</h3>
      <p class="small">Activate an investment tier to start earning daily profit. Pick the tier that matches your
        budget and follow the deposit steps.</p>
      <div class="grid g-2 mt-16" style="gap:12px">
        ${PLANS.map((p) => `<div class="mini-row"><div><b>${UIx.esc(p.name)}</b>
          <div class="tiny muted">${UIx.money(p.amount)} · ${(p.dailyRate * 100).toFixed(1)}% daily</div></div>
          <a class="btn btn-outline btn-sm" href="deposit.html?plan=${p.id}">Select</a></div>`).join("")}
      </div>`;
    return;
  }

  const plan = user.plan;
  const daily = plan.amount * plan.dailyRate;
  const daysPaid = Math.min(UIx.daysBetween(plan.startedAt, plan.lastProfitAt), plan.duration);
  const progress = Math.round((daysPaid / plan.duration) * 100);
  const finished = !!plan.endedAt;
  const endsAt = new Date(plan.startedAt);
  endsAt.setDate(endsAt.getDate() + plan.duration);

  wrap.innerHTML = `
    <div class="between mb-16">
      <div>
        <div class="tiny muted" style="letter-spacing:.14em;text-transform:uppercase;font-weight:800">Active plan</div>
        <h2 class="mb-0">${UIx.esc(plan.name)}</h2>
      </div>
      <span class="badge ${finished ? "badge-neutral" : "badge-active"}">${finished ? "Cycle Completed" : "Running"}</span>
    </div>
    <div class="grid g-2" style="gap:12px">
      <div class="mini-row"><span class="muted small">Invested</span><b>${UIx.money(plan.amount)}</b></div>
      <div class="mini-row"><span class="muted small">Daily profit</span><b class="accent">${UIx.money(daily)}</b></div>
      <div class="mini-row"><span class="muted small">Started</span><b>${UIx.date(plan.startedAt)}</b></div>
      <div class="mini-row"><span class="muted small">Ends</span><b>${UIx.date(endsAt.toISOString())}</b></div>
    </div>
    <div class="mt-24">
      <div class="between mb-8">
        <span class="small muted">Cycle progress · ${daysPaid}/${plan.duration} days credited</span>
        <span class="small accent"><b>${progress}%</b></span>
      </div>
      <div class="progress"><i style="width:${progress}%"></i></div>
    </div>
    <div class="grid g-2 mt-24" style="gap:12px">
      <div class="mini-row"><span class="muted small">Profit paid so far</span><b class="up">${UIx.money(daily * daysPaid)}</b></div>
      <div class="mini-row"><span class="muted small">Projected total return</span><b>${UIx.money(plan.amount + daily * plan.duration)}</b></div>
    </div>
    ${finished ? `<a class="btn btn-primary btn-block mt-24" href="plans.html">Start a new cycle</a>` : ""}`;
}

function renderRecent(user) {
  const wrap = document.getElementById("recentActivity");
  if (!wrap) return;
  const list = Ledger.forUser(user.id, 6);
  if (!list.length) {
    wrap.innerHTML = `<p class="small muted mb-0">No activity yet. Your daily profit will appear here.</p>`;
    return;
  }
  wrap.innerHTML = list.map((t, i) => `
    <div class="timeline-item">
      <div class="marker"><span class="dot" style="background:${t.amount < 0 ? "var(--danger)" : "var(--accent)"}"></span>
        ${i === list.length - 1 ? "" : '<span class="bar"></span>'}</div>
      <div class="content">
        <div class="between" style="gap:10px">
          <div><b class="small">${UIx.esc(t.note)}</b>
            <div class="tiny muted">${UIx.dateTime(t.createdAt)} · ${UIx.timeAgo(t.createdAt)}</div></div>
          <b class="${t.amount < 0 ? "down" : "up"} mono">${t.amount < 0 ? "−" : "+"} ${UIx.money(Math.abs(t.amount), false)}</b>
        </div>
      </div>
    </div>`).join("");
}

function renderRefSnapshot(user) {
  const wrap = document.getElementById("refSnapshot");
  if (!wrap) return;
  const team = DB.users.filter((u) => u.referredBy === user.username);
  const activeTeam = team.filter((u) => u.plan && !u.plan.endedAt);
  wrap.innerHTML = `
    <div class="mini-row"><span class="muted small">Direct referrals</span><b>${team.length}</b></div>
    <div class="mini-row"><span class="muted small">Team with active plans</span><b>${activeTeam.length}</b></div>
    <div class="mini-row"><span class="muted small">Commission payouts received</span><b>${user.referralCommissionCount || 0}</b></div>
    <div class="mini-row"><span class="muted small">Lifetime referral earnings</span><b class="accent">${UIx.money(user.referralEarnings)}</b></div>
    <div class="mini-row"><span class="muted small">Instant bonus rate</span><b>${(SETTINGS.referralInstantRate * 100).toFixed(0)}%</b></div>
    <div class="mini-row"><span class="muted small">Recurring rate</span><b>${(SETTINGS.referralDailyRate * 100).toFixed(1)}% daily</b></div>`;
}

function renderSummary(user) {
  const wrap = document.getElementById("summaryList");
  if (!wrap) return;
  const rows = [
    ["Available balance", UIx.money(user.balance)],
    ["Total deposited", UIx.money(user.totalDeposits)],
    ["Total profit credited", UIx.money(user.totalProfit)],
    ["Total referral earnings", UIx.money(user.referralEarnings)],
    ["Total withdrawn", UIx.money(user.totalWithdrawn)],
    ["Account status", user.status === "blocked" ? "Blocked" : "Active"]
  ];
  wrap.innerHTML = rows.map(([k, v]) => `<div class="mini-row"><span class="muted small">${k}</span><b>${v}</b></div>`).join("");

  const inv = document.getElementById("investBreakdown");
  if (inv) {
    const tx = Ledger.forUser(user.id);
    const profit = tx.filter((t) => t.type === "profit").reduce((s, t) => s + t.amount, 0);
    const referral = tx.filter((t) => t.type === "referral").reduce((s, t) => s + t.amount, 0);
    const withdrawn = tx.filter((t) => t.type === "withdraw" && t.amount < 0).reduce((s, t) => s + Math.abs(t.amount), 0);
    inv.innerHTML = `
      <div class="mini-row"><span class="muted small">Profit entries logged</span><b>${tx.filter((t) => t.type === "profit").length}</b></div>
      <div class="mini-row"><span class="muted small">Referral credits logged</span><b>${tx.filter((t) => t.type === "referral").length}</b></div>
      <div class="mini-row"><span class="muted small">Gross profit credited</span><b class="up">${UIx.money(profit)}</b></div>
      <div class="mini-row"><span class="muted small">Gross referral credited</span><b class="up">${UIx.money(referral)}</b></div>
      <div class="mini-row"><span class="muted small">Gross withdrawals requested</span><b class="down">${UIx.money(withdrawn)}</b></div>`;
  }
}

function renderTables(user) {
  const deps = DB.deposits.filter((d) => d.userId === user.id);
  const depWrap = document.getElementById("depositTable");
  if (depWrap) {
    depWrap.innerHTML = `<div class="table-wrap"><table class="data-table">
      <thead><tr><th>Date</th><th>Plan</th><th>Amount</th><th>Sender No.</th><th>TID</th><th>Status</th><th>Note</th></tr></thead>
      <tbody>${deps.length ? deps.map((d) => `
        <tr>
          <td class="tiny muted">${UIx.dateTime(d.createdAt)}</td>
          <td><b>${UIx.esc(d.planName)}</b></td>
          <td class="mono">${UIx.money(d.amount)}</td>
          <td class="mono tiny">${UIx.esc(d.senderNumber)}</td>
          <td class="mono tiny">${UIx.esc(d.tid)}</td>
          <td>${statusBadge(d.status)}</td>
          <td class="tiny muted">${UIx.esc(d.note || "—")}</td>
        </tr>`).join("") : emptyRow(7, "No deposit requests yet.")}</tbody></table></div>`;
  }

  const wds = DB.withdrawals.filter((w) => w.userId === user.id);
  const wdWrap = document.getElementById("withdrawTable");
  if (wdWrap) {
    wdWrap.innerHTML = `<div class="table-wrap"><table class="data-table">
      <thead><tr><th>Date</th><th>Amount</th><th>Method</th><th>Account Title</th><th>Account No.</th><th>Status</th><th>Note</th></tr></thead>
      <tbody>${wds.length ? wds.map((w) => `
        <tr>
          <td class="tiny muted">${UIx.dateTime(w.createdAt)}</td>
          <td class="mono">${UIx.money(w.amount)}</td>
          <td>${UIx.esc(w.method)}</td>
          <td class="tiny">${UIx.esc(w.title)}</td>
          <td class="mono tiny">${UIx.esc(w.accountNumber)}</td>
          <td>${statusBadge(w.status)}</td>
          <td class="tiny muted">${UIx.esc(w.note || "—")}</td>
        </tr>`).join("") : emptyRow(7, "No withdrawal requests yet.")}</tbody></table></div>`;
  }

  const tx = Ledger.forUser(user.id);
  const txWrap = document.getElementById("txTable");
  if (txWrap) {
    txWrap.innerHTML = `<div class="table-wrap"><table class="data-table">
      <thead><tr><th>Date</th><th>Type</th><th>Description</th><th>Amount</th></tr></thead>
      <tbody>${tx.length ? tx.map((t) => `
        <tr>
          <td class="tiny muted">${UIx.dateTime(t.createdAt)}</td>
          <td>${txBadge(t.type)}</td>
          <td class="small">${UIx.esc(t.note)}</td>
          <td class="mono ${t.amount < 0 ? "down" : "up"}">${t.amount < 0 ? "−" : "+"} ${UIx.money(Math.abs(t.amount))}</td>
        </tr>`).join("") : emptyRow(4, "No transactions recorded yet.")}</tbody></table></div>`;
  }

  const team = DB.users.filter((u) => u.referredBy === user.username);
  const teamWrap = document.getElementById("teamTable");
  if (teamWrap) {
    const ledger = Ledger.forUser(user.id).filter((t) => t.type === "referral");
    teamWrap.innerHTML = `<div class="table-wrap"><table class="data-table">
      <thead><tr><th>Member</th><th>Joined</th><th>Plan</th><th>Status</th><th>Commission Earned</th></tr></thead>
      <tbody>${team.length ? team.map((m) => {
        const earned = ledger.filter((t) => t.note.indexOf("@" + m.username) > -1).reduce((s, t) => s + t.amount, 0);
        return `<tr>
          <td><b>@${UIx.esc(m.username)}</b><div class="tiny muted">${UIx.esc(m.firstName)} ${UIx.esc(m.lastName)}</div></td>
          <td class="tiny muted">${UIx.date(m.createdAt)}</td>
          <td class="tiny">${UIx.esc(m.plan ? m.plan.name : "No active plan")}</td>
          <td><span class="badge ${m.plan && !m.plan.endedAt ? "badge-active" : "badge-neutral"}">${m.plan && !m.plan.endedAt ? "Earning" : "Idle"}</span></td>
          <td class="mono accent">${UIx.money(earned)}</td>
        </tr>`;
      }).join("") : emptyRow(5, "You have no referrals yet — share your link from the referral page.")}</tbody></table></div>`;
  }
}

function renderProfile(user) {
  const wrap = document.getElementById("profileList");
  if (!wrap) return;
  const rows = [
    ["Full name", `${user.firstName} ${user.lastName}`],
    ["Username", "@" + user.username],
    ["Email", user.email],
    ["Phone", user.phone],
    ["Referral code", user.referralCode],
    ["Referred by", user.referredBy ? "@" + user.referredBy : "Direct sign-up"],
    ["Registered on", UIx.date(user.createdAt)]
  ];
  wrap.innerHTML = rows.map(([k, v]) => `<div class="mini-row"><span class="muted small">${k}</span><b class="small">${UIx.esc(v)}</b></div>`).join("");
}

/* ------------------------------ Live refresh ---------------------------- */
function refreshDashboard(user) {
  renderKPIs(user);
  renderPlan(user);
  renderRecent(user);
  renderRefSnapshot(user);
  renderSummary(user);
  renderTables(user);
  renderProfile(user);
}

function initDashboard() {
  const user = Layout.requireAuth();
  if (!user) return null;

  if (user.status === "blocked") {
    Toast.show("Your account is currently blocked. Contact support.", "error");
  }

  setText("dashTitle", "Welcome back, " + (user.firstName || user.username));
  setText("dashJoined", UIx.date(user.createdAt));
  setText("dashRefCode", user.referralCode);
  const statusEl = document.getElementById("dashStatus");
  if (statusEl) {
    statusEl.textContent = user.status === "blocked" ? "Blocked" : "Active";
    statusEl.className = "badge " + (user.status === "blocked" ? "badge-blocked" : "badge-active");
  }

  refreshDashboard(user);

  document.querySelectorAll("[data-goto]").forEach((el) => {
    el.addEventListener("click", (e) => {
      e.preventDefault();
      Tabs.open(el.dataset.goto);
      window.scrollTo({ top: document.querySelector(".tabs").offsetTop - 100, behavior: "smooth" });
    });
  });

  const logoutBtn = document.getElementById("logoutBtnPage");
  if (logoutBtn) {
    logoutBtn.addEventListener("click", () => {
      Auth.logout();
      window.location.href = "index.html";
    });
  }

  if (user.plan && !user.plan.endedAt) {
    Toast.show("Daily profit is accruing on your " + user.plan.name + " plan.", "success");
  }

  return user;
}

document.addEventListener("DOMContentLoaded", () => {
  Veltra.onReady(() => {
    if (!initDashboard()) return;
    /* Refresh the dashboard when the backend pushes new data. */
    Veltra.onChange(() => {
      const fresh = Auth.current();
      if (fresh) refreshDashboard(fresh);
    });
  });
});
