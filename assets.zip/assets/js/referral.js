/* ==========================================================================
   Veltra — Referral / Affiliate Program Page
   ========================================================================== */

function refTable() {
  const body = document.getElementById("refTableBody");
  if (!body) return;
  body.innerHTML = PLANS.map((p) => {
    const daily = p.amount * p.dailyRate;
    const instant = p.amount * SETTINGS.referralInstantRate;
    const dailyComm = daily * SETTINGS.referralDailyRate;
    return `
      <tr>
        <td><b>${UIx.esc(p.name)}</b></td>
        <td class="mono">${UIx.money(p.amount)}</td>
        <td class="mono">${UIx.money(daily)}</td>
        <td class="mono accent"><b>${UIx.money(instant)}</b></td>
        <td class="mono accent">${UIx.money(dailyComm)} / day</td>
        <td class="mono up">${UIx.money(dailyComm * p.duration)}</td>
      </tr>`;
  }).join("");
}

function refStats(user) {
  const grid = document.getElementById("refStatsGrid");
  if (!grid) return;
  const team = DB.users.filter((u) => u.referredBy === user.username);
  const activeTeam = team.filter((u) => u.plan && !u.plan.endedAt);
  const commissions = Ledger.forUser(user.id).filter((t) => t.type === "referral");
  const totalCommission = commissions.reduce((s, t) => s + t.amount, 0);
  const todayCommission = commissions
    .filter((t) => UIx.daysBetween(t.createdAt, new Date()) === 0)
    .reduce((s, t) => s + t.amount, 0);

  grid.innerHTML = `
    <div class="kpi"><div class="kpi-top"><span class="kpi-label">Direct Referrals</span><span class="icon-box" style="width:36px;height:36px;flex:0 0 36px">👥</span></div>
      <div class="kpi-value">${team.length}</div><div class="tiny muted">${activeTeam.length} with active plans</div></div>
    <div class="kpi"><div class="kpi-top"><span class="kpi-label">Total Commission Earned</span><span class="icon-box" style="width:36px;height:36px;flex:0 0 36px">₨</span></div>
      <div class="kpi-value accent">${UIx.money(totalCommission)}</div><div class="tiny muted">Across ${commissions.length} payouts</div></div>
    <div class="kpi"><div class="kpi-top"><span class="kpi-label">Today's Commission</span><span class="icon-box" style="width:36px;height:36px;flex:0 0 36px">📈</span></div>
      <div class="kpi-value up">${UIx.money(todayCommission)}</div><div class="tiny muted">1.5% daily recurring</div></div>
    <div class="kpi"><div class="kpi-top"><span class="kpi-label">Referral Earnings Balance</span><span class="icon-box" style="width:36px;height:36px;flex:0 0 36px">🏦</span></div>
      <div class="kpi-value">${UIx.money(user.referralEarnings || 0)}</div><div class="tiny muted">Lifetime commission credits</div></div>`;
}

function refList(user) {
  const wrap = document.getElementById("refList");
  if (!wrap) return;
  const team = DB.users.filter((u) => u.referredBy === user.username);
  if (!team.length) {
    wrap.innerHTML = `<div class="empty-state"><div class="icon">👥</div>
      <p class="mb-8">No referrals yet.</p>
      <p class="tiny">Share your link above — the first approved deposit pays you 10% instantly.</p></div>`;
    return;
  }
  const ledger = Ledger.forUser(user.id).filter((t) => t.type === "referral");
  wrap.innerHTML = `<div class="table-wrap"><table class="data-table" style="min-width:560px">
    <thead><tr><th>Member</th><th>Joined</th><th>Plan</th><th>Status</th><th>Your Earnings</th></tr></thead>
    <tbody>${team.map((m) => {
      const earned = ledger.filter((t) => t.note.indexOf("@" + m.username) > -1)
        .reduce((s, t) => s + t.amount, 0);
      const planLabel = m.plan ? m.plan.name : "No active plan";
      return `<tr>
        <td><b>@${UIx.esc(m.username)}</b><div class="tiny muted">${UIx.esc(m.firstName)} ${UIx.esc(m.lastName)}</div></td>
        <td class="tiny muted">${UIx.date(m.createdAt)}</td>
        <td class="tiny">${UIx.esc(planLabel)}</td>
        <td><span class="badge ${m.status === "blocked" ? "badge-blocked" : m.plan && !m.plan.endedAt ? "badge-active" : "badge-neutral"}">${m.status === "blocked" ? "Blocked" : m.plan && !m.plan.endedAt ? "Earning" : "Idle"}</span></td>
        <td class="mono accent">${UIx.money(earned)}</td>
      </tr>`;
    }).join("")}</tbody></table></div>`;
}

function initReferral() {
  refTable();

  const input = document.getElementById("refLinkInput");
  const badge = document.getElementById("refCodeBadge");
  const copyBtn = document.getElementById("copyRefBtn");
  const hint = document.getElementById("refLinkHint");
  const user = Auth.current();

  if (!user) {
    const demo = "register.html?ref=YOURCODE";
    if (input) input.value = demo;
    if (badge) badge.textContent = "Guest";
    if (copyBtn) {
      copyBtn.textContent = "Create Account";
      copyBtn.addEventListener("click", () => (window.location.href = "register.html"));
    }
    const grid = document.getElementById("refStatsGrid");
    if (grid) {
      grid.innerHTML = [
        ["Sign up free", "Takes under a minute"],
        ["Get your link", "Unique referral code"],
        ["Earn 10% instantly", "On first deposits"],
        ["Earn 1.5% daily", "Recurring commissions"]
      ].map(([t, s]) => `<div class="kpi"><div class="kpi-label">${t}</div>
        <div class="small muted mt-8">${s}</div></div>`).join("");
    }
    return;
  }

  const base = window.location.href.replace(/referral\.html.*$/, "register.html");
  const link = base + "?ref=" + encodeURIComponent(user.referralCode);
  if (input) input.value = link;
  if (badge) badge.textContent = user.referralCode;
  if (hint) hint.textContent = "Share this link — your code is applied automatically when a new member registers.";
  if (copyBtn) copyBtn.addEventListener("click", () => copyText(link, "Referral link copied"));

  refStats(user);
  refList(user);
}

document.addEventListener("DOMContentLoaded", () => Veltra.onReady(initReferral));
