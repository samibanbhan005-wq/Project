/* ==========================================================================
   Veltra — Home Page
   ========================================================================== */

const FEED_LABELS = {
  deposit: "New investment deposit",
  profit: "Daily profit credited",
  withdraw: "Withdrawal dispatched",
  referral: "Referral commission paid"
};

const FEED_SIGNS = { deposit: "+", profit: "+", referral: "+", withdraw: "−" };

const RANDOM_NAMES = ["Faisal", "Zainab", "Usman", "Maryam", "Talha", "Iqra", "Rehan", "Noor",
  "Saad", "Hina", "Danish", "Amna", "Kashif", "Rabia", "Junaid", "Mehwish", "Arsalan", "Farah"];

function feedRow(item) {
  const sign = FEED_SIGNS[item.type] || "+";
  const cls = item.type === "withdraw" ? "down" : "up";
  return `
    <div class="feed-row">
      <span class="avatar" style="width:34px;height:34px;flex:0 0 34px">${UIx.esc(UIx.maskUser(item.name).charAt(0))}</span>
      <div>
        <div class="who">${UIx.esc(UIx.maskUser(item.name))}</div>
        <div class="what">${FEED_LABELS[item.type] || "Transaction"} · ${UIx.timeAgo(item.at)}</div>
      </div>
      <div class="amount ${cls}">${sign} ${UIx.money(item.amount)}</div>
      <span class="badge badge-active">Verified</span>
    </div>`;
}

function renderFeed(list) {
  const wrap = document.getElementById("homeFeed");
  if (!wrap) return;
  wrap.innerHTML = list.slice(0, 12).map(feedRow).join("");
}

function pushLiveFeed() {
  const types = ["deposit", "profit", "withdraw", "referral"];
  const type = types[Math.floor(Math.random() * types.length)];
  const base = type === "deposit" ? 1200 + Math.random() * 2800 : 60 + Math.random() * 4200;
  const item = {
    name: RANDOM_NAMES[Math.floor(Math.random() * RANDOM_NAMES.length)] + Math.floor(10 + Math.random() * 89),
    type,
    amount: Math.round(base * 100) / 100,
    at: new Date().toISOString()
  };
  const feed = DB.feed;
  feed.unshift(item);
  DB.feed = feed.slice(0, 120);
  renderFeed(DB.feed);
}

function renderTicker() {
  const track = document.getElementById("tickerTrack");
  if (!track) return;
  const items = DB.feed.slice(0, 14).map((f) => `
    <span class="ticker-item">
      <span class="live-dot"></span>
      ${UIx.esc(UIx.maskUser(f.name))} · ${UIx.esc(FEED_LABELS[f.type])}
      <b>${FEED_SIGNS[f.type]} ${UIx.money(f.amount)}</b>
    </span>`).join("");
  track.innerHTML = items + items; /* duplicated for a seamless loop */
}

function initCounters() {
  const cards = document.querySelectorAll("[data-count]");
  const run = (el) => {
    const target = Number(el.dataset.count);
    const compact = el.dataset.compact === "1";
    const prefix = el.dataset.prefix || "";
    const suffix = el.dataset.suffix || "";
    const decimals = Number(el.dataset.decimals || 0);
    if (compact) {
      const start = performance.now();
      const step = (now) => {
        const p = Math.min((now - start) / 1500, 1);
        const eased = 1 - Math.pow(1 - p, 3);
        el.textContent = prefix + UIx.compact(target * eased);
        if (p < 1) requestAnimationFrame(step);
        else el.textContent = prefix + UIx.compact(target) + suffix;
      };
      requestAnimationFrame(step);
    } else {
      animateCount(el, target, { prefix, decimals });
      if (suffix) setTimeout(() => { el.textContent = el.textContent + suffix; }, 1550);
    }
  };
  if ("IntersectionObserver" in window) {
    const io = new IntersectionObserver((entries) => {
      entries.forEach((e) => {
        if (e.isIntersecting) { run(e.target); io.unobserve(e.target); }
      });
    }, { threshold: 0.4 });
    cards.forEach((c) => io.observe(c));
  } else {
    cards.forEach(run);
  }
}

function initTrust() {
  const users = document.getElementById("trustUsers");
  const invested = document.getElementById("trustInvested");
  const paid = document.getElementById("trustPaid");
  if (users) animateCount(users, 11840);
  if (invested) {
    const start = performance.now();
    const step = (now) => {
      const p = Math.min((now - start) / 1500, 1);
      const eased = 1 - Math.pow(1 - p, 3);
      invested.textContent = UIx.compact(42000000 * eased);
      if (p < 1) requestAnimationFrame(step);
    };
    requestAnimationFrame(step);
  }
  if (paid) {
    const start = performance.now();
    const step = (now) => {
      const p = Math.min((now - start) / 1500, 1);
      const eased = 1 - Math.pow(1 - p, 3);
      paid.textContent = UIx.compact(15600000 * eased);
      if (p < 1) requestAnimationFrame(step);
    };
    requestAnimationFrame(step);
  }
}

function renderSnapshot() {
  const s = Admin.stats();
  setText("snapPendingWd", s.pendingWithdrawals);
  setText("snapActivePlans", s.investingUsers);
  setText("snapReferral", UIx.money(s.referralPayouts));
}

function initHome() {
  /* Plans preview */
  const planWrap = document.getElementById("homePlans");
  if (planWrap) {
    planWrap.innerHTML = PLANS.map((p) => PlanCard.render(p, {
      compact: true, featured: p.id === "advanced", cta: "Choose " + p.name, href: "plans.html"
    })).join("");
  }

  /* Live feed */
  renderFeed(DB.feed);
  renderTicker();
  setInterval(pushLiveFeed, 6000);
  setInterval(renderTicker, 45000);

  /* Counters */
  initCounters();
  initTrust();

  /* Platform snapshot from the live database */
  renderSnapshot();

  /* Personalise the mockup for signed-in users */
  const user = Auth.current();
  if (user) {
    setText("mockBalance", UIx.money(user.balance));
    const cta = document.querySelector(".hero-actions .btn-primary");
    if (cta) { cta.textContent = "Go to Dashboard"; cta.href = "dashboard.html"; }
    const cta2 = document.querySelector(".hero-actions .btn-outline");
    if (cta2) { cta2.textContent = "Deposit Funds"; cta2.href = "deposit.html"; }
  }
}

document.addEventListener("DOMContentLoaded", () => {
  Veltra.onReady(() => {
    initHome();
    /* Reflect live backend activity in the feed, ticker and snapshot. */
    Veltra.onChange(() => {
      renderFeed(DB.feed);
      renderTicker();
      renderSnapshot();
    });
  });
});
