/* ==========================================================================
   Veltra — Admin Control Panel
   ========================================================================== */

let ADMIN = null;

/* ------------------------------ small helpers ---------------------------- */
function badge(status) {
  const map = { pending: "badge-pending", approved: "badge-approved", rejected: "badge-rejected" };
  const label = { pending: "Pending", approved: "Approved", rejected: "Rejected" };
  return `<span class="badge ${map[status] || "badge-neutral"}">${label[status] || status}</span>`;
}

function emptyTable(cols, text) {
  return `<tr><td colspan="${cols}"><div class="empty-state"><div class="icon">◎</div>
    <p class="mb-0">${UIx.esc(text)}</p></div></td></tr>`;
}

/* --------------------------------- modal -------------------------------- */
function openAction(title, bodyHtml, confirmText, onConfirm, variant) {
  setText("modalTitle", title);
  document.getElementById("modalBody").innerHTML = bodyHtml;
  const confirmBtn = document.getElementById("modalConfirm");
  confirmBtn.textContent = confirmText;
  confirmBtn.className = "btn " + (variant || "btn-primary");
  confirmBtn.onclick = () => {
    const proceed = onConfirm();
    if (proceed !== false) Modal.close("actionModal");
  };
  Modal.open("actionModal");
}

/* -------------------------------- overview ------------------------------- */
function renderOverview() {
  const s = Admin.stats();

  const kpis = [
    ["Total Deposits", UIx.money(s.totalDeposits), s.depositCount + " approved deposits", "₨"],
    ["Total Payouts", UIx.money(s.totalPayouts), "Dispatched withdrawals", "↗"],
    ["User Balances", UIx.money(s.totalBalances), "Held across all accounts", "🏦"],
    ["Referral Payouts", UIx.money(s.referralPayouts), "Instant + daily commissions", "👥"]
  ];
  document.getElementById("adminKpis").innerHTML = kpis.map(([label, value, sub, icon]) => `
    <div class="kpi">
      <div class="kpi-top"><span class="kpi-label">${label}</span>
        <span class="icon-box" style="width:36px;height:36px;flex:0 0 36px">${icon}</span></div>
      <div class="kpi-value">${value}</div>
      <div class="tiny muted">${sub}</div>
    </div>`).join("");

  const finance = [
    ["Registered users", s.totalUsers],
    ["Active accounts", s.activeUsers],
    ["Blocked accounts", s.blockedUsers],
    ["Members with running plans", s.investingUsers],
    ["Profit credited to users", UIx.money(s.totalProfitPaid)],
    ["Pending deposit requests", s.pendingDeposits],
    ["Pending withdrawal requests", s.pendingWithdrawals],
    ["Referral payouts released", UIx.money(s.referralPayouts)]
  ];
  document.getElementById("financeList").innerHTML = finance
    .map(([k, v]) => `<div class="mini-row"><span class="muted small">${k}</span><b>${v}</b></div>`).join("");

  const recent = DB.transactions.slice(0, 8);
  document.getElementById("adminRecent").innerHTML = recent.length
    ? recent.map((t) => `
      <div class="mini-row">
        <div><b class="small">@${UIx.esc(t.username)}</b>
          <div class="tiny muted">${UIx.esc(t.note)}</div></div>
        <div class="text-right">
          <b class="mono ${t.amount < 0 ? "down" : "up"}">${t.amount < 0 ? "−" : "+"} ${UIx.money(Math.abs(t.amount), false)}</b>
          <div class="tiny muted">${UIx.timeAgo(t.createdAt)}</div>
        </div>
      </div>`).join("")
    : `<p class="small muted mb-0">No activity recorded yet.</p>`;

  const pending = s.pendingDeposits + s.pendingWithdrawals;
  setText("pendingBadges", pending + " pending");
  const pdep = document.getElementById("pillDeposits");
  const pwd = document.getElementById("pillWithdrawals");
  pdep.textContent = s.pendingDeposits;
  pdep.classList.toggle("hidden", s.pendingDeposits === 0);
  pwd.textContent = s.pendingWithdrawals;
  pwd.classList.toggle("hidden", s.pendingWithdrawals === 0);
}

/* --------------------------------- users -------------------------------- */
function renderUsers() {
  const q = (document.getElementById("userSearch").value || "").trim().toLowerCase();
  const users = DB.users
    .filter((u) => u.role !== "admin")
    .filter((u) => !q || u.username.toLowerCase().includes(q) || u.email.toLowerCase().includes(q) || u.phone.includes(q))
    .sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));

  document.getElementById("userTable").innerHTML = `<div class="table-wrap"><table class="data-table">
    <thead><tr><th>Member</th><th>Contact</th><th>Plan</th><th>Balance</th><th>Referrals</th><th>Status</th><th>Actions</th></tr></thead>
    <tbody>${users.length ? users.map((u) => `
      <tr>
        <td>
          <b>@${UIx.esc(u.username)}</b>
          <div class="tiny muted">${UIx.esc(u.firstName)} ${UIx.esc(u.lastName)} · joined ${UIx.date(u.createdAt)}</div>
        </td>
        <td class="tiny">
          <div>${UIx.esc(u.email)}</div>
          <div class="muted">${UIx.esc(u.phone)}</div>
        </td>
        <td class="tiny">${u.plan ? `${UIx.esc(u.plan.name)}<div class="muted">${UIx.money(u.plan.amount)}</div>` : '<span class="badge badge-neutral">None</span>'}</td>
        <td class="mono">${UIx.money(u.balance)}<div class="tiny muted">in ${UIx.money(u.totalDeposits)}</div></td>
        <td class="tiny">${u.referralCount || 0}<div class="muted">${UIx.money(u.referralEarnings || 0)}</div></td>
        <td><span class="badge ${u.status === "blocked" ? "badge-blocked" : "badge-active"}">${u.status === "blocked" ? "Blocked" : "Active"}</span></td>
        <td>
          <div class="flex gap-8">
            <button class="btn btn-outline btn-sm" data-view-user="${u.id}">View</button>
            <button class="btn btn-outline btn-sm" data-edit-balance="${u.id}">Balance</button>
            <button class="btn ${u.status === "blocked" ? "btn-success" : "btn-danger"} btn-sm" data-toggle-block="${u.id}">
              ${u.status === "blocked" ? "Activate" : "Block"}</button>
          </div>
        </td>
      </tr>`).join("") : emptyTable(7, "No users matched your search.")}</tbody></table></div>`;

  bindUserActions();
}

function bindUserActions() {
  document.querySelectorAll("[data-view-user]").forEach((btn) => {
    btn.addEventListener("click", () => {
      const u = DB.users.find((x) => x.id === btn.dataset.viewUser);
      if (!u) return;
      const deps = DB.deposits.filter((d) => d.userId === u.id).length;
      const wds = DB.withdrawals.filter((w) => w.userId === u.id).length;
      const team = DB.users.filter((x) => x.referredBy === u.username).length;
      openAction("Member profile — @" + u.username, `
        <div class="grid" style="gap:10px">
          <div class="mini-row"><span class="muted small">Name</span><b>${UIx.esc(u.firstName)} ${UIx.esc(u.lastName)}</b></div>
          <div class="mini-row"><span class="muted small">Email</span><b class="small">${UIx.esc(u.email)}</b></div>
          <div class="mini-row"><span class="muted small">Phone</span><b>${UIx.esc(u.phone)}</b></div>
          <div class="mini-row"><span class="muted small">Referral code</span><b class="mono">${UIx.esc(u.referralCode)}</b></div>
          <div class="mini-row"><span class="muted small">Referred by</span><b>${u.referredBy ? "@" + UIx.esc(u.referredBy) : "—"}</b></div>
          <div class="mini-row"><span class="muted small">Balance</span><b class="accent">${UIx.money(u.balance)}</b></div>
          <div class="mini-row"><span class="muted small">Total deposited</span><b>${UIx.money(u.totalDeposits)}</b></div>
          <div class="mini-row"><span class="muted small">Total profit</span><b class="up">${UIx.money(u.totalProfit)}</b></div>
          <div class="mini-row"><span class="muted small">Referral earnings</span><b class="accent">${UIx.money(u.referralEarnings)}</b></div>
          <div class="mini-row"><span class="muted small">Active plan</span><b>${u.plan ? UIx.esc(u.plan.name) : "None"}</b></div>
          <div class="mini-row"><span class="muted small">Deposits / Withdrawals</span><b>${deps} / ${wds}</b></div>
          <div class="mini-row"><span class="muted small">Team size</span><b>${team}</b></div>
        </div>`, "Close", () => true, "btn-outline");
    });
  });

  document.querySelectorAll("[data-edit-balance]").forEach((btn) => {
    btn.addEventListener("click", () => {
      const u = DB.users.find((x) => x.id === btn.dataset.editBalance);
      if (!u) return;
      openAction("Adjust balance — @" + u.username, `
        <p class="small">Current balance: <b class="accent">${UIx.money(u.balance)}</b></p>
        <div class="form-group">
          <label class="form-label">New balance (PKR)</label>
          <input class="form-control mono" id="newBalance" type="number" min="0" step="0.01" value="${Number(u.balance).toFixed(2)}" />
        </div>
        <div class="form-group">
          <label class="form-label">Reason / note</label>
          <input class="form-control" id="balanceNote" placeholder="e.g. Manual profit adjustment" />
        </div>`, "Update Balance", () => {
        const val = document.getElementById("newBalance").value;
        const note = document.getElementById("balanceNote").value.trim();
        const res = Admin.adjustBalance(u.id, val, note, ADMIN.username);
        if (!res.ok) { Toast.show(res.error, "error"); return false; }
        Toast.show("Balance updated for @" + u.username, "success");
        renderAll();
      });
    });
  });

  document.querySelectorAll("[data-toggle-block]").forEach((btn) => {
    btn.addEventListener("click", () => {
      const u = DB.users.find((x) => x.id === btn.dataset.toggleBlock);
      if (!u) return;
      const blocking = u.status !== "blocked";
      openAction((blocking ? "Block" : "Activate") + " account — @" + u.username,
        `<p class="small">${blocking
          ? "The member will be signed out of their session and unable to log in until reactivated."
          : "The member will regain access to their dashboard immediately."}</p>`,
        blocking ? "Block Account" : "Activate Account", () => {
          const res = Admin.toggleBlock(u.id, ADMIN.username);
          if (!res.ok) { Toast.show(res.error, "error"); return false; }
          Toast.show(`@${u.username} is now ${res.status}.`, "success");
          renderAll();
        }, blocking ? "btn-danger" : "btn-success");
    });
  });
}

/* -------------------------------- deposits ------------------------------- */
function renderDeposits() {
  const filter = document.getElementById("depFilter").value;
  const list = DB.deposits.filter((d) => filter === "all" || d.status === filter);

  document.getElementById("depositTable").innerHTML = `<div class="table-wrap"><table class="data-table">
    <thead><tr><th>Submitted</th><th>Member</th><th>Plan</th><th>Amount</th><th>Sender No.</th><th>TID</th><th>Status</th><th>Actions</th></tr></thead>
    <tbody>${list.length ? list.map((d) => `
      <tr>
        <td class="tiny muted">${UIx.dateTime(d.createdAt)}</td>
        <td><b>@${UIx.esc(d.username)}</b><div class="tiny muted">${UIx.esc(d.name)}</div>
          <div class="tiny muted">${UIx.esc(d.email)}</div></td>
        <td class="tiny"><b>${UIx.esc(d.planName)}</b></td>
        <td class="mono">${UIx.money(d.amount)}</td>
        <td class="mono tiny">${UIx.esc(d.senderNumber)}</td>
        <td class="mono tiny">${UIx.esc(d.tid)}</td>
        <td>${badge(d.status)}${d.status === "rejected" && d.note ? `<div class="tiny muted">${UIx.esc(d.note)}</div>` : ""}</td>
        <td>${d.status === "pending" ? `
          <div class="flex gap-8">
            <button class="btn btn-success btn-sm" data-approve-dep="${d.id}">Approve</button>
            <button class="btn btn-danger btn-sm" data-reject-dep="${d.id}">Reject</button>
          </div>` : `<span class="tiny muted">Processed ${UIx.date(d.reviewedAt)}</span>`}</td>
      </tr>`).join("") : emptyTable(8, "No deposits found for this filter.")}</tbody></table></div>`;

  document.querySelectorAll("[data-approve-dep]").forEach((btn) => {
    btn.addEventListener("click", () => {
      const d = DB.deposits.find((x) => x.id === btn.dataset.approveDep);
      if (!d) return;
      openAction("Approve deposit — " + UIx.money(d.amount), `
        <div class="grid" style="gap:10px">
          <div class="mini-row"><span class="muted small">Member</span><b>@${UIx.esc(d.username)}</b></div>
          <div class="mini-row"><span class="muted small">Plan</span><b>${UIx.esc(d.planName)}</b></div>
          <div class="mini-row"><span class="muted small">Amount</span><b class="accent">${UIx.money(d.amount)}</b></div>
          <div class="mini-row"><span class="muted small">Sender number</span><b>${UIx.esc(d.senderNumber)}</b></div>
          <div class="mini-row"><span class="muted small">TID</span><b class="mono">${UIx.esc(d.tid)}</b></div>
        </div>
        <div class="alert alert-info mt-16"><span>ℹ</span><div>Approving will activate the plan for this member and
          automatically release the <b>10% instant referral bonus</b> if this is their first deposit.</div></div>`,
        "Approve & Activate", () => {
          const res = Deposits.approve(d.id, ADMIN.username);
          if (!res.ok) { Toast.show(res.error, "error"); return false; }
          Toast.show(res.bonusPaid
            ? `Deposit approved. Referral bonus ${UIx.money(res.bonusPaid)} released.`
            : "Deposit approved and plan activated.", "success");
          renderAll();
        }, "btn-success");
    });
  });

  document.querySelectorAll("[data-reject-dep]").forEach((btn) => {
    btn.addEventListener("click", () => {
      const d = DB.deposits.find((x) => x.id === btn.dataset.rejectDep);
      if (!d) return;
      openAction("Reject deposit — @" + d.username, `
        <p class="small">Rejecting <b>${UIx.money(d.amount)}</b> (TID ${UIx.esc(d.tid)}). No balance is credited
          and no plan is activated.</p>
        <div class="form-group">
          <label class="form-label">Reason shown to the member</label>
          <textarea class="form-control" id="rejectNote" placeholder="e.g. Payment not found against the submitted TID."></textarea>
        </div>`, "Reject Deposit", () => {
        const note = document.getElementById("rejectNote").value.trim();
        if (note.length < 4) { Toast.show("Please provide a rejection reason.", "error"); return false; }
        const res = Deposits.reject(d.id, note, ADMIN.username);
        if (!res.ok) { Toast.show(res.error, "error"); return false; }
        Toast.show("Deposit rejected.", "warn");
        renderAll();
      }, "btn-danger");
    });
  });
}

/* ------------------------------ withdrawals ------------------------------ */
function renderWithdrawals() {
  const filter = document.getElementById("wdFilter").value;
  const list = DB.withdrawals.filter((w) => filter === "all" || w.status === filter);

  document.getElementById("wdTable").innerHTML = `<div class="table-wrap"><table class="data-table">
    <thead><tr><th>Requested</th><th>Member</th><th>Amount</th><th>Method</th><th>Title</th><th>Account No.</th><th>Status</th><th>Actions</th></tr></thead>
    <tbody>${list.length ? list.map((w) => `
      <tr>
        <td class="tiny muted">${UIx.dateTime(w.createdAt)}</td>
        <td><b>@${UIx.esc(w.username)}</b></td>
        <td class="mono">${UIx.money(w.amount)}</td>
        <td class="tiny">${UIx.esc(w.method)}</td>
        <td class="tiny">${UIx.esc(w.title)}</td>
        <td class="mono tiny">${UIx.esc(w.accountNumber)}</td>
        <td>${w.status === "approved"
            ? '<span class="badge badge-approved">Dispatched</span>'
            : badge(w.status)}${w.status === "rejected" && w.note ? `<div class="tiny muted">${UIx.esc(w.note)}</div>` : ""}</td>
        <td>${w.status === "pending" ? `
          <div class="flex gap-8">
            <button class="btn btn-success btn-sm" data-dispatch-wd="${w.id}">Dispatch</button>
            <button class="btn btn-danger btn-sm" data-reject-wd="${w.id}">Reject</button>
          </div>` : `<span class="tiny muted">Processed ${UIx.date(w.reviewedAt)}</span>`}</td>
      </tr>`).join("") : emptyTable(8, "No withdrawal requests found for this filter.")}</tbody></table></div>`;

  document.querySelectorAll("[data-dispatch-wd]").forEach((btn) => {
    btn.addEventListener("click", () => {
      const w = DB.withdrawals.find((x) => x.id === btn.dataset.dispatchWd);
      if (!w) return;
      openAction("Dispatch payout — " + UIx.money(w.amount), `
        <p class="small">Confirm that <b>${UIx.money(w.amount)}</b> has been sent to
          <b>${UIx.esc(w.method)}</b> account <b class="mono">${UIx.esc(w.accountNumber)}</b>
          (${UIx.esc(w.title)}).</p>
        <div class="alert alert-info"><span>ℹ</span><div>The held amount is already deducted from the member's
          balance — dispatching simply marks the request as paid.</div></div>`,
        "Mark as Dispatched", () => {
          const res = Withdrawals.dispatch(w.id, ADMIN.username);
          if (!res.ok) { Toast.show(res.error, "error"); return false; }
          Toast.show("Payout marked as dispatched.", "success");
          renderAll();
        }, "btn-success");
    });
  });

  document.querySelectorAll("[data-reject-wd]").forEach((btn) => {
    btn.addEventListener("click", () => {
      const w = DB.withdrawals.find((x) => x.id === btn.dataset.rejectWd);
      if (!w) return;
      openAction("Reject withdrawal — @" + w.username, `
        <p class="small">Rejecting will <b>auto-refund ${UIx.money(w.amount)}</b> to the member's balance.</p>
        <div class="form-group">
          <label class="form-label">Reason shown to the member</label>
          <textarea class="form-control" id="wdRejectNote" placeholder="e.g. Account title does not match the account number."></textarea>
        </div>`, "Reject & Refund", () => {
        const note = document.getElementById("wdRejectNote").value.trim();
        if (note.length < 4) { Toast.show("Please provide a rejection reason.", "error"); return false; }
        const res = Withdrawals.reject(w.id, note, ADMIN.username);
        if (!res.ok) { Toast.show(res.error, "error"); return false; }
        Toast.show("Withdrawal rejected — amount refunded to balance.", "warn");
        renderAll();
      }, "btn-danger");
    });
  });
}

/* --------------------------------- ledger -------------------------------- */
function renderLedger() {
  const tx = DB.transactions.slice(0, 120);
  document.getElementById("ledgerTable").innerHTML = `<div class="table-wrap"><table class="data-table">
    <thead><tr><th>Date</th><th>Member</th><th>Type</th><th>Description</th><th>Amount</th></tr></thead>
    <tbody>${tx.length ? tx.map((t) => `
      <tr>
        <td class="tiny muted">${UIx.dateTime(t.createdAt)}</td>
        <td class="tiny"><b>@${UIx.esc(t.username)}</b></td>
        <td><span class="badge badge-neutral">${UIx.esc(t.type)}</span></td>
        <td class="small">${UIx.esc(t.note)}</td>
        <td class="mono ${t.amount < 0 ? "down" : "up"}">${t.amount < 0 ? "−" : "+"} ${UIx.money(Math.abs(t.amount))}</td>
      </tr>`).join("") : emptyTable(5, "No transactions recorded yet.")}</tbody></table></div>`;
}

/* --------------------------------- shell --------------------------------- */
function renderAll() {
  renderOverview();
  renderUsers();
  renderDeposits();
  renderWithdrawals();
  renderLedger();
}

function initAdmin() {
  ADMIN = Layout.requireAdmin();
  if (!ADMIN) return;

  /* Sidebar navigation */
  const nav = document.getElementById("adminNav");
  nav.querySelectorAll("button").forEach((btn) => {
    btn.addEventListener("click", () => {
      nav.querySelectorAll("button").forEach((b) => b.classList.remove("active"));
      btn.classList.add("active");
      document.querySelectorAll(".admin-panel").forEach((p) => {
        p.classList.toggle("active", p.dataset.panel === btn.dataset.panel);
      });
    });
  });

  /* Modal close buttons */
  document.querySelectorAll("[data-close-modal]").forEach((el) => {
    el.addEventListener("click", () => Modal.close("actionModal"));
  });

  /* Filters */
  document.getElementById("userSearch").addEventListener("input", renderUsers);
  document.getElementById("depFilter").addEventListener("change", renderDeposits);
  document.getElementById("wdFilter").addEventListener("change", renderWithdrawals);

  renderAll();
  Toast.show("Signed in as administrator.", "success");
  return ADMIN;
}

document.addEventListener("DOMContentLoaded", () => {
  Veltra.onReady(() => {
    if (!initAdmin()) return;
    /* Live admin view — reflect deposits/withdrawals as they happen. */
    Veltra.onChange(renderAll);
  });
});
