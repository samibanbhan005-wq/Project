/* ==========================================================================
   Veltra — Firebase Realtime Database REST client
   A dependency-free wrapper around the Firebase RTDB REST API so the whole
   platform runs on a real backend without any build step or SDK bundle.

   Endpoints used:
     GET    <url>/<path>.json          → read a node (or the whole tree)
     PUT    <url>/<path>.json          → overwrite a node
     PATCH  <url>/<path>.json          → merge into a node
     DELETE <url>/<path>.json          → remove a node
     GET    <url>/<path>.json (stream) → live updates via EventSource

   NOTE: this database is intentionally left open in the Firebase console for
   the demo build. A production deployment must enable Firebase security
   rules (auth-backed) and move password hashing server-side.
   ========================================================================== */
(function (global) {
  "use strict";

  const BASE_URL = "https://proj-b5312-default-rtdb.asia-southeast1.firebasedatabase.app";
  const ROOT = BASE_URL.replace(/\/+$/, "");
  const DEFAULT_TIMEOUT = 12000;

  /** Builds the REST endpoint for a database path. */
  function endpoint(path) {
    const clean = String(path == null ? "" : path).replace(/^\/+|\/+$/g, "");
    return ROOT + "/" + (clean ? clean + ".json" : ".json");
  }

  /** Performs a JSON request with an abort-based timeout. */
  async function request(path, options) {
    const opts = options || {};
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), opts.timeout || DEFAULT_TIMEOUT);
    try {
      const res = await fetch(endpoint(path), {
        method: opts.method || "GET",
        headers: opts.body !== undefined ? { "Content-Type": "application/json" } : undefined,
        body: opts.body,
        cache: "no-store",
        signal: controller.signal
      });
      if (!res.ok) {
        throw new Error("Firebase " + (opts.method || "GET") + " " + res.status + " on /" + path);
      }
      const text = await res.text();
      return text ? JSON.parse(text) : null;
    } finally {
      clearTimeout(timer);
    }
  }

  const FirebaseDB = {
    baseUrl: ROOT,

    /** Reads a node. Returns the parsed JSON value (null when empty). */
    get(path) {
      return request(path, { method: "GET" });
    },

    /** Overwrites a node with the given value. */
    put(path, value) {
      return request(path, { method: "PUT", body: JSON.stringify(value === undefined ? null : value) });
    },

    /** Merges the given keys into an existing node. */
    patch(path, value) {
      return request(path, { method: "PATCH", body: JSON.stringify(value === undefined ? null : value) });
    },

    /** Deletes a node. */
    remove(path) {
      return request(path, { method: "DELETE" });
    },

    /**
     * Subscribes to live changes on a node using the REST event-stream API.
     * The callback receives { type, path, data } for every put/patch event.
     * Returns the EventSource (reconnects automatically) or null if
     * streaming is unavailable.
     */
    watch(path, onEvent) {
      if (typeof global.EventSource !== "function") return null;

      let source;
      try {
        source = new global.EventSource(endpoint(path));
      } catch (e) {
        return null;
      }

      const handler = (type) => (ev) => {
        if (!ev || !ev.data) return;
        let payload;
        try { payload = JSON.parse(ev.data); } catch (e) { return; }
        if (!payload || payload.data === undefined) return;
        try {
          onEvent({ type, path: payload.path || "/", data: payload.data });
        } catch (e) {
          console.warn("[Veltra] stream handler failed", e);
        }
      };

      source.addEventListener("put", handler("put"));
      source.addEventListener("patch", handler("patch"));
      source.addEventListener("keep-alive", () => { /* heartbeat — ignore */ });
      source.onerror = () => { /* EventSource reconnects on its own */ };

      return source;
    }
  };

  global.FirebaseDB = FirebaseDB;
})(window);
