/* ==========================================================================
   Veltra — Withdraw Request Page
   ========================================================================== */

function renderWithdrawHistory(user) {
  const wrap = document.getElementById("wdHistory");
  if (!wrap) return;
  const list = DB.withdrawals.filter((w) => w.userId === user.id);
  if (!list.length) {
    wrap.innerHTML = `<div class="empty-state" style="padding:28px"><div class="icon">◎</div>
      <p class="mb-0 small">No withdrawal requests yet.</p></div>`;
    return;
  }
  wrap.innerHTML = `<div class="grid" style="gap:10px">${list.slice(0, 6).map((w) => `
    <div class="mini-row">
      <div>
        <b class="small">${UIx.money(w.amount)} · ${UIx.esc(w.method)}</b>
        <div class="tiny muted">${UIx.esc(w.accountNumber)} · ${UIx.dateTime(w.createdAt)}</div>
      </div>
      <span class="badge ${w.status === "pending" ? "badge-pending" : w.status === "approved" ? "badge-approved" : "badge-rejected"}">
        ${w.status === "approved" ? "Dispatched" : w.status.charAt(0).toUpperCase() + w.status.slice(1)}</span>
    </div>`).join("")}</div>`;
}

function initWithdraw() {
  const user = Layout.requireAuth();
  if (!user) return;

  const amountEl = document.getElementById("wAmount");
  const methodEl = document.getElementById("wMethod");
  const titleEl = document.getElementById("wTitle");
  const accountEl = document.getElementById("wAccount");
  const previewEl = document.getElementById("wdPreview");

  methodEl.innerHTML = WITHDRAW_METHODS.map((m) => `<option>${m}</option>`).join("");
  titleEl.value = `${user.firstName} ${user.lastName}`.trim();
  if (user.phone) accountEl.value = user.phone;

  function refreshStats() {
    const fresh = Auth.current();
    setText("wdBalance", UIx.money(fresh.balance));
    setText("wdTotal", UIx.money(fresh.totalWithdrawn));
    setText("wdMin", UIx.money(SETTINGS.minWithdraw));
    const pending = DB.withdrawals.filter((w) => w.userId === fresh.id && w.status === "pending");
    setText("wdPending", pending.length);
  }

  function refreshPreview() {
    const fresh = Auth.current();
    const amount = Number(amountEl.value);
    if (!amount || amount <= 0) {
      previewEl.innerHTML = "Enter an amount to see your balance after this request.";
      return;
    }
    const after = Number(fresh.balance) - amount;
    if (after < 0) {
      previewEl.innerHTML = `<b class="down">Insufficient balance.</b> You can withdraw up to ${UIx.money(fresh.balance)}.`;
      return;
    }
    previewEl.innerHTML = `Requesting <b>${UIx.money(amount)}</b> · balance after hold:
      <b class="accent">${UIx.money(after)}</b>`;
  }

  document.querySelectorAll("[data-pct]").forEach((btn) => {
    btn.addEventListener("click", () => {
      const fresh = Auth.current();
      const pct = Number(btn.dataset.pct) / 100;
      amountEl.value = (Number(fresh.balance) * pct).toFixed(2);
      refreshPreview();
    });
  });

  amountEl.addEventListener("input", refreshPreview);

  document.getElementById("withdrawForm").addEventListener("submit", (e) => {
    e.preventDefault();
    const res = Withdrawals.submit(Auth.current(), {
      amount: Number(amountEl.value),
      method: methodEl.value,
      title: titleEl.value.trim(),
      accountNumber: accountEl.value.trim()
    });

    if (!res.ok) return Toast.show(res.error, "error");

    Toast.show("Withdrawal request submitted — amount placed on hold.", "success");
    amountEl.value = "";
    refreshStats();
    refreshPreview();
    renderWithdrawHistory(Auth.current());
    Layout.render();
  });

  refreshStats();
  refreshPreview();
  renderWithdrawHistory(user);
}

document.addEventListener("DOMContentLoaded", () => Veltra.onReady(initWithdraw));
