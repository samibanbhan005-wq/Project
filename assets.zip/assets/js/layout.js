/* ==========================================================================
   Veltra — Shared Layout & UI Kit
   Injects the header/footer, handles navigation, auth-aware UI, toasts,
   tabs and modals so every page stays consistent.
   ========================================================================== */

window.Fmt = UIx;
window.VeltraSettings = SETTINGS;

/* --------------------------- App boot shell ------------------------------ */
/* A lightweight overlay shown while the Firebase backend is being reached,
   plus a fixed connectivity indicator driven by Veltra's sync status. */
const Loader = {
  show() {
    if (document.getElementById("appLoader")) return;
    const el = document.createElement("div");
    el.id = "appLoader";
    el.className = "app-loader";
    el.innerHTML = `
      <div class="app-loader-box">
        <span class="brand-mark">V</span>
        <div class="spinner"></div>
        <div class="app-loader-text">Connecting to Veltra secure server…</div>
        <div class="app-loader-sub">Syncing your account from the live database</div>
      </div>`;
    document.body.appendChild(el);
  },
  hide() {
    const el = document.getElementById("appLoader");
    if (!el) return;
    el.classList.add("done");
    setTimeout(() => el.remove(), 420);
  },
  fail(message) {
    const el = document.getElementById("appLoader");
    if (!el) return;
    const text = el.querySelector(".app-loader-text");
    const sub = el.querySelector(".app-loader-sub");
    if (text) text.textContent = message;
    if (sub) sub.textContent = "Showing cached data — changes will sync when reconnected.";
    el.classList.add("error");
  }
};
window.Loader = Loader;

const Connection = {
  el: null,
  ensure() {
    if (this.el) return this.el;
    const el = document.createElement("div");
    el.id = "connBadge";
    el.className = "conn-badge pending";
    el.innerHTML = `<span class="conn-dot"></span><span class="conn-text">Connecting…</span>`;
    document.body.appendChild(el);
    this.el = el;
    return el;
  },
  set(online) {
    const el = this.ensure();
    el.classList.toggle("online", !!online);
    el.classList.toggle("offline", !online);
    el.classList.remove("pending");
    el.querySelector(".conn-text").textContent = online ? "Live" : "Offline";
  }
};

const NAV_LINKS = [
  { href: "index.html", label: "Home", page: "home" },
  { href: "plans.html", label: "Plans", page: "plans" },
  { href: "referral.html", label: "Referral", page: "referral" },
  { href: "how-it-works.html", label: "How It Works", page: "how" },
  { href: "deposit.html", label: "Deposit", page: "deposit" },
  { href: "withdraw.html", label: "Withdraw", page: "withdraw" },
  { href: "dashboard.html", label: "Dashboard", page: "dashboard" },
  { href: "contact.html", label: "Contact", page: "contact" }
];

const Layout = {
  page() {
    return (document.body && document.body.dataset.page) || "";
  },

  headerHtml(user) {
    const current = Layout.page();
    const links = NAV_LINKS.map((l) => {
      const active = l.page === current ? " active" : "";
      const hide = l.page === "dashboard" && !user ? " style=\"display:none\"" : "";
      return `<a class="nav-link${active}"${hide} href="${l.href}">${l.label}</a>`;
    }).join("");

    const mobileLinks = NAV_LINKS.map((l) => {
      const active = l.page === current ? " active" : "";
      const hide = l.page === "dashboard" && !user ? " style=\"display:none\"" : "";
      return `<a${hide} class="${active.trim()}" href="${l.href}">${l.label}</a>`;
    }).join("");

    let actions;
    if (user) {
      const initials = (user.firstName || user.username || "U").charAt(0).toUpperCase() +
        (user.lastName || "").charAt(0).toUpperCase();
      actions = `
        <div class="user-chip" id="userChip">
          <button class="user-chip-btn" type="button" aria-haspopup="true" aria-expanded="false">
            <span class="avatar">${UIx.esc(initials)}</span>
            <span class="small" style="font-weight:700">${UIx.esc(user.firstName || user.username)}</span>
            <span class="muted" style="font-size:.7rem">▾</span>
          </button>
          <div class="dropdown" id="userMenu">
            <div class="dd-head">
              <div class="small" style="font-weight:700">${UIx.esc(user.username)}</div>
              <div class="tiny muted">Balance: ${UIx.money(user.balance)}</div>
            </div>
            <a href="dashboard.html">◧ Dashboard</a>
            <a href="deposit.html">＋ Deposit</a>
            <a href="withdraw.html">↗ Withdraw</a>
            <a href="referral.html">⇗ Referral Program</a>
            ${user.role === "admin" ? '<a href="admin.html">⚙ Admin Panel</a>' : ""}
            <button type="button" id="logoutBtn">⏻ Log out</button>
          </div>
        </div>`;
    } else {
      actions = `
        <a class="btn btn-outline btn-sm" href="login.html">Login</a>
        <a class="btn btn-primary btn-sm hide-sm" href="register.html">Get Started</a>`;
    }

    return `
      <header class="site-header">
        <div class="container">
          <a class="brand" href="index.html"><span class="brand-mark">V</span>Veltra<span class="dot">.</span></a>
          <nav class="nav">${links}</nav>
          <div class="header-actions">
            ${actions}
            <button class="hamburger" type="button" id="navToggle" aria-label="Menu">☰</button>
          </div>
        </div>
      </header>
      <nav class="mobile-nav" id="mobileNav">${mobileLinks}</nav>`;
  },

  footerHtml() {
    const year = new Date().getFullYear();
    return `
      <footer class="site-footer">
        <div class="container">
          <div class="footer-grid">
            <div>
              <a class="brand" href="index.html"><span class="brand-mark">V</span>Veltra<span class="dot">.</span></a>
              <p class="small mt-16">Veltra is a digital investment platform offering structured daily-profit plans,
                instant referral rewards and secure local payouts across Pakistan.</p>
              <div class="social-row">
                <a href="#" aria-label="Facebook">f</a>
                <a href="#" aria-label="Instagram">◎</a>
                <a href="#" aria-label="WhatsApp">✆</a>
                <a href="#" aria-label="Telegram">✈</a>
              </div>
            </div>
            <div>
              <h4>Platform</h4>
              <a href="plans.html">Investment Plans</a>
              <a href="how-it-works.html">How It Works</a>
              <a href="referral.html">Referral Program</a>
              <a href="dashboard.html">User Dashboard</a>
            </div>
            <div>
              <h4>Payments</h4>
              <a href="deposit.html">Deposit Funds</a>
              <a href="withdraw.html">Request Withdrawal</a>
              <a href="how-it-works.html#faq">FAQs</a>
              <a href="contact.html">Support Center</a>
            </div>
            <div>
              <h4>Get In Touch</h4>
              <a href="mailto:${SETTINGS.supportEmail}">${SETTINGS.supportEmail}</a>
              <a href="tel:${SETTINGS.supportPhone.replace(/\s/g, "")}">${SETTINGS.supportPhone}</a>
              <div class="copy-value mt-16">
                <span class="tiny muted">Support hours<br><b class="accent">Mon – Sat, 10am – 8pm</b></span>
              </div>
              <p class="tiny muted mt-16 mb-0">Investments carry risk. Only invest what you can afford.</p>
            </div>
          </div>
          <div class="footer-bottom">
            <span>© ${year} Veltra. All rights reserved.</span>
            <span>Terms &nbsp;·&nbsp; Privacy Policy &nbsp;·&nbsp; Risk Disclosure &nbsp;·&nbsp; AML Policy</span>
          </div>
        </div>
      </footer>`;
  },

  render() {
    const user = Auth.current();
    const headerSlot = document.getElementById("app-header");
    const footerSlot = document.getElementById("app-footer");
    if (headerSlot) headerSlot.innerHTML = Layout.headerHtml(user);
    if (footerSlot) footerSlot.innerHTML = Layout.footerHtml();
    Layout.bind(user);
  },

  bind(user) {
    const toggle = document.getElementById("navToggle");
    const mobile = document.getElementById("mobileNav");
    if (toggle && mobile) {
      toggle.addEventListener("click", () => {
        mobile.classList.toggle("open");
        toggle.textContent = mobile.classList.contains("open") ? "✕" : "☰";
      });
    }

    const chip = document.getElementById("userChip");
    const menu = document.getElementById("userMenu");
    if (chip && menu) {
      chip.querySelector(".user-chip-btn").addEventListener("click", (e) => {
        e.stopPropagation();
        menu.classList.toggle("open");
      });
      /* Bound once — the header is re-rendered on live updates. */
      if (!Layout._docBound) {
        Layout._docBound = true;
        document.addEventListener("click", () => {
          const m = document.getElementById("userMenu");
          if (m) m.classList.remove("open");
        });
      }
    }

    const logout = document.getElementById("logoutBtn");
    if (logout) {
      logout.addEventListener("click", () => {
        Auth.logout();
        Toast.show("You have been logged out.", "success");
        setTimeout(() => (window.location.href = "index.html"), 600);
      });
    }
  },

  /** Redirects guests to the login page, preserving the return URL. */
  requireAuth() {
    const user = Auth.current();
    if (!user) {
      const next = encodeURIComponent(window.location.pathname.split("/").pop() || "dashboard.html");
      window.location.href = "login.html?next=" + next;
      return null;
    }
    return user;
  },

  requireAdmin() {
    const user = Auth.current();
    if (!user || user.role !== "admin") {
      window.location.href = "login.html?next=admin.html";
      return null;
    }
    return user;
  }
};

/* ------------------------------- Toasts ---------------------------------- */
const Toast = {
  wrap() {
    let el = document.querySelector(".toast-wrap");
    if (!el) {
      el = document.createElement("div");
      el.className = "toast-wrap";
      document.body.appendChild(el);
    }
    return el;
  },
  show(message, type) {
    const el = document.createElement("div");
    el.className = "toast " + (type || "");
    el.innerHTML = UIx.esc(message);
    Toast.wrap().appendChild(el);
    setTimeout(() => {
      el.style.transition = "opacity .3s, transform .3s";
      el.style.opacity = "0";
      el.style.transform = "translateX(20px)";
      setTimeout(() => el.remove(), 320);
    }, 3400);
  }
};
window.Toast = Toast;

/* -------------------------------- Tabs ----------------------------------- */
const Tabs = {
  init() {
    document.querySelectorAll(".tabs").forEach((group) => {
      group.querySelectorAll(".tab").forEach((tab) => {
        tab.addEventListener("click", () => {
          const target = tab.dataset.tab;
          const scope = group.parentElement || document;
          group.querySelectorAll(".tab").forEach((t) => t.classList.remove("active"));
          tab.classList.add("active");
          scope.querySelectorAll(".tab-panel").forEach((p) => {
            p.classList.toggle("active", p.dataset.panel === target);
          });
          if (typeof window.onTabChange === "function") window.onTabChange(target);
        });
      });
    });
  },
  open(target) {
    const tab = document.querySelector(`.tab[data-tab="${target}"]`);
    if (tab) tab.click();
  }
};
window.Tabs = Tabs;

/* ------------------------------- Modal ---------------------------------- */
const Modal = {
  open(id) {
    const m = document.getElementById(id);
    if (m) m.classList.add("open");
  },
  close(id) {
    const m = document.getElementById(id);
    if (m) m.classList.remove("open");
  },
  init() {
    document.querySelectorAll(".modal-overlay").forEach((ov) => {
      ov.addEventListener("click", (e) => {
        if (e.target === ov) ov.classList.remove("open");
      });
    });
  }
};
window.Modal = Modal;

/* ---------------------------- Small utilities --------------------------- */
function copyText(value, label) {
  const text = String(value);
  const done = () => Toast.show((label || "Copied") + ": " + text, "success");
  if (navigator.clipboard && navigator.clipboard.writeText) {
    navigator.clipboard.writeText(text).then(done).catch(() => fallbackCopy(text, done));
  } else {
    fallbackCopy(text, done);
  }
}
function fallbackCopy(text, done) {
  const ta = document.createElement("textarea");
  ta.value = text;
  ta.style.position = "fixed";
  ta.style.opacity = "0";
  document.body.appendChild(ta);
  ta.select();
  try { document.execCommand("copy"); done(); } catch (e) { Toast.show("Copy failed — please copy manually.", "error"); }
  ta.remove();
}
window.copyText = copyText;

/** Formats a number as Pakistani Rupees inside an element id. */
function setText(id, value) {
  const el = document.getElementById(id);
  if (el) el.textContent = value;
}
window.setText = setText;

/** Simple, dependency-free animated counter. */
function animateCount(el, target, options) {
  const opts = options || {};
  const duration = opts.duration || 1400;
  const prefix = opts.prefix || "";
  const decimals = opts.decimals || 0;
  const start = performance.now();
  function frame(now) {
    const p = Math.min((now - start) / duration, 1);
    const eased = 1 - Math.pow(1 - p, 3);
    const val = target * eased;
    el.textContent = prefix + val.toLocaleString("en-PK", {
      minimumFractionDigits: decimals, maximumFractionDigits: decimals
    });
    if (p < 1) requestAnimationFrame(frame);
  }
  requestAnimationFrame(frame);
}
window.animateCount = animateCount;

/* --------------------------- Plan card renderer -------------------------- */
const PlanCard = {
  render(plan, opts) {
    const o = opts || {};
    const daily = plan.amount * plan.dailyRate;
    const total = plan.amount + daily * plan.duration;
    const features = (o.compact ? plan.perks.slice(0, 3) : plan.perks)
      .map((p) => `<li>${UIx.esc(p)}</li>`).join("");
    return `
      <article class="card card-hover plan-card${o.featured ? " featured" : ""}">
        ${plan.tag ? `<span class="plan-tag">${UIx.esc(plan.tag)}</span>` : ""}
        <div class="tiny muted" style="letter-spacing:.14em;text-transform:uppercase;font-weight:800">${UIx.esc(plan.name)}</div>
        <div class="plan-price">${UIx.money(plan.amount, false)}<small> PKR</small></div>
        <div class="small muted">One-time investment · ${plan.duration} days cycle</div>
        <div class="plan-meta">
          <div><b class="accent">${(plan.dailyRate * 100).toFixed(1)}%</b><span>Daily profit</span></div>
          <div><b>${UIx.money(daily, false)}</b><span>Per day (Rs)</span></div>
          <div><b>${plan.duration} days</b><span>Active cycle</span></div>
          <div><b>${UIx.money(total, false)}</b><span>Total return (Rs)</span></div>
        </div>
        <ul class="plan-features">${features}</ul>
        <a class="btn ${o.featured ? "btn-primary" : "btn-outline"} btn-block" href="${o.href || "plans.html"}">${UIx.esc(o.cta || "View Plan")}</a>
      </article>`;
  }
};
window.PlanCard = PlanCard;

/* ------------------------------- App boot -------------------------------- */
Loader.show();
Connection.ensure();

if (window.Veltra) {
  Veltra.onStatus((online) => Connection.set(online));

  Veltra.onReady(() => {
    Loader.hide();
    Layout.render();
    Tabs.init();
    Modal.init();
    /* Keep the header (balance / auth state) fresh on live backend updates. */
    Veltra.onChange(() => Layout.render());
  });
} else {
  document.addEventListener("DOMContentLoaded", () => {
    Loader.hide();
    Layout.render();
    Tabs.init();
    Modal.init();
  });
}
